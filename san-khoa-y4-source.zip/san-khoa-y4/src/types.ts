export type Difficulty = 1 | 2 | 3 | 4;
export interface Question {
  id: string;
  subject: string;
  grade: number;
  chapter: string;
  lesson: string;
  topic: string;
  difficulty: Difficulty;
  type: "multiple_choice";
  question: string;
  clinicalCase?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  source: { documentId: string; locator: string };
  updates?: { title: string; url: string; year: number; note: string }[];
  image?: {
    src: string;
    alt: string;
    caption: string;
    sourceUrl: string;
    credit: string;
    license: string;
  };
}
export interface ExamConfig {
  subject?: string;
  grade?: number;
  chapters?: string[];
  name: string;
  count: number;
  minutes: number;
  mode: "exam" | "practice";
  ratios: number[];
  topics: string[];
  lessons: string[];
  images: "all" | "with" | "without";
}
export interface ExamQuestion extends Question {
  optionOrder: number[];
}
export interface Attempt {
  id: string;
  bankVersion: string;
  algorithmVersion: string;
  seed: string;
  config: ExamConfig;
  questions: ExamQuestion[];
  answers: Record<string, number>;
  flags: string[];
  current: number;
  startedAt: number;
  deadline: number | null;
  completedAt: number | null;
  status: "active" | "completed";
  completionReason?: "manual" | "expired";
}
export interface SourceRecord {
  id: string;
  title: string;
  folder: string;
  collection: string;
  units: number;
  characters: number;
  error: string | null;
}
export const LEVELS = ["Nhận biết", "Thông hiểu", "Vận dụng", "Vận dụng cao"];
export const DEFAULT_CONFIG: ExamConfig = {
  subject: "Sản khoa",
  grade: 4,
  chapters: [],
  name: "",
  count: 90,
  minutes: 90,
  mode: "exam",
  ratios: [10, 15, 40, 35],
  topics: [],
  lessons: [],
  images: "all",
};
export const TOPICS = [
  {
    id: "thai-som",
    title: "Ba tháng đầu thai kỳ",
    short: "Thai sớm",
    description: "Tuổi thai, thai ngoài tử cung, sẩy thai và nguyên bào nuôi.",
    color: "#dceee9",
    icon: "Sprout",
  },
  {
    id: "cham-soc-thai",
    title: "Quản lý nửa đầu thai kỳ",
    short: "Chăm sóc thai",
    description: "Khám thai, tầm soát, dinh dưỡng và nhiễm trùng thai kỳ.",
    color: "#eee6f6",
    icon: "HeartPulse",
  },
  {
    id: "suc-khoe-thai",
    title: "Lượng giá sức khỏe thai",
    short: "Sức khỏe thai",
    description: "Tăng trưởng, nước ối, Doppler và theo dõi sức khỏe thai.",
    color: "#e0edf8",
    icon: "Activity",
  },
  {
    id: "benh-ly-thai",
    title: "Quản lý nửa sau thai kỳ",
    short: "Bệnh lý thai kỳ",
    description: "Tiền sản giật, đái tháo đường, sinh non và ối vỡ non.",
    color: "#f4e8dc",
    icon: "Stethoscope",
  },
  {
    id: "chuyen-da",
    title: "Quản lý chuyển dạ",
    short: "Chuyển dạ",
    description: "Theo dõi chuyển dạ, ngôi thai, can thiệp và hồi sức sơ sinh.",
    color: "#e7e9f8",
    icon: "Waves",
  },
  {
    id: "cap-cuu",
    title: "Cấp cứu Sản khoa",
    short: "Cấp cứu",
    description: "Băng huyết, bất thường bánh nhau, vỡ tử cung và sốc.",
    color: "#f6e1e2",
    icon: "ShieldPlus",
  },
  {
    id: "hau-san",
    title: "Chăm sóc mẹ và con",
    short: "Hậu sản",
    description: "Hậu sản, nuôi con bằng sữa mẹ và chăm sóc sơ sinh.",
    color: "#eef0d9",
    icon: "Baby",
  },
];
