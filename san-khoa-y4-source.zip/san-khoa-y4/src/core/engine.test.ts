import { describe, it, expect, beforeEach } from "vitest";
import "fake-indexeddb/auto";
import Papa from "papaparse";
import { parseBank } from "./files";
import { DEFAULT_CONFIG, type Question } from "../types";
import {
  quotas,
  createAttempt,
  selectQuestions,
  grade,
  finish,
  expired,
  filterBank,
  sharePayload,
  decodeShare,
  fingerprint,
  wrongPractice,
  retryAttempt,
  breakdown,
  chooseSeed,
  canShare,
} from "./engine";
import { validateQuestions, validateAttempts } from "./validation";
import {
  saveAttempt,
  readState,
  deleteAttempt,
  saveBank,
  resetBank,
  importAttempts,
  restoreAttempt,
} from "./storage";
const bank: Question[] = Array.from({ length: 160 }, (_, i) => ({
  id: "Q" + i,
  subject: "Sản khoa",
  grade: 4,
  chapter: "C" + (i % 2),
  lesson: "L" + (i % 3),
  topic: "T" + (i % 2),
  difficulty: (Math.floor(i / 40) + 1) as Question["difficulty"],
  type: "multiple_choice",
  question: "Câu kiểm thử " + i,
  options: ["a", "b", "c", "d"],
  correctAnswer: i % 4,
  explanation: "Căn cứ đáp án",
  source: { documentId: "S1", locator: "trang 1" },
}));
const config = { ...DEFAULT_CONFIG, count: 20, name: "Tên riêng" };
describe("Tạo đề và chấm kết quả", () => {
  it("chia90câu theo tỉ lệ đã duyệt và xử lý phần dư", () =>
    expect(quotas(90, [10, 15, 40, 35])).toEqual([9, 13, 36, 32]));
  it("giữ đúng tổng cho nhiều số câu và tỉ lệ có phần dư", () => {
    for (let n = 1; n < 200; n++) {
      const q = quotas(n, [10, 15, 40, 35]);
      expect(q.reduce((a, b) => a + b, 0)).toBe(n);
      expect(q.every((x) => Number.isInteger(x) && x >= 0)).toBe(true);
    }
  });
  it("từ chối tỉ lệ sai và số câu không nguyên", () => {
    expect(() => quotas(90, [10, 20, 30, 30])).toThrow();
    expect(() => quotas(1.2, [10, 15, 40, 35])).toThrow();
    expect(() => quotas(90, [10, 15, 40, NaN])).toThrow();
  });
  it("lọc đúng phạm vi chủ đề/bài và câu có ảnh", () => {
    const found = filterBank(bank, {
      ...config,
      topics: ["T1"],
      lessons: ["L2"],
    });
    expect(found.length).toBeGreaterThan(0);
    expect(found.every((q) => q.topic === "T1" && q.lesson === "L2")).toBe(
      true,
    );
    expect(filterBank(bank, { ...config, images: "with" })).toEqual([]);
  });
  it("lọc riêng môn, năm học và chương để không trộn ngân hàng mở rộng", () => {
    const other = {
      ...bank[0],
      id: "OTHER",
      subject: "Phụ khoa",
      grade: 5,
      chapter: "Khác",
    };
    const pool = filterBank([...bank, other], {
      ...config,
      subject: "Phụ khoa",
      grade: 5,
      chapters: ["Khác"],
    });
    expect(pool).toEqual([other]);
    expect(
      filterBank([...bank, other], { ...config, subject: "Sản khoa", grade: 4 })
        .length,
    ).toBe(bank.length);
  });
  it("số câu và mức độ chính xác, không có ID lặp", () => {
    const q = selectQuestions(bank, config, "fixed");
    expect(q.length).toBe(20);
    expect(new Set(q.map((x) => x.id)).size).toBe(20);
    expect(
      [1, 2, 3, 4].map((l) => q.filter((x) => x.difficulty === l).length),
    ).toEqual([2, 3, 8, 7]);
  });
  it("thiếu một mức phải báo, không lấy ngoài phạm vi", () => {
    expect(() =>
      selectQuestions(bank, { ...config, count: 90, topics: ["T1"] }, "s"),
    ).toThrow("chưa đủ");
    expect(() =>
      selectQuestions(bank, { ...config, topics: ["absent"] }, "s"),
    ).toThrow();
  });
  it("cùng seed/cấu hình/bank giữ thứ tự câu và phương án", () => {
    expect(selectQuestions(bank, config, "same")).toEqual(
      selectQuestions([...bank].reverse(), config, "same"),
    );
    expect(selectQuestions(bank, config, "other")).not.toEqual(
      selectQuestions(bank, config, "same"),
    );
  });
  it("xáo phương án vẫn chấm đúng mọi đáp án", () => {
    const a = createAttempt(bank, config, [], "x", 1000);
    a.questions.forEach((q) => {
      a.answers[q.id] = q.optionOrder.indexOf(q.correctAnswer);
    });
    expect(grade(a)).toMatchObject({
      correct: 20,
      wrong: 0,
      blank: 0,
      total: 20,
    });
    expect(a.questions.every((q) => new Set(q.optionOrder).size === 4)).toBe(
      true,
    );
  });
  it("phân biệt đúng/sai/bỏ trống", () => {
    const a = createAttempt(bank, config, [], "x", 1000);
    a.answers[a.questions[0].id] = a.questions[0].optionOrder.indexOf(
      a.questions[0].correctAnswer,
    );
    a.answers[a.questions[1].id] = a.questions[1].optionOrder.indexOf(
      (a.questions[1].correctAnswer + 1) % 4,
    );
    expect(grade(a)).toMatchObject({ correct: 1, wrong: 1, blank: 18 });
  });
  it("deadline giữ nguyên khi khôi phục, phát hiện bài quá hạn", () => {
    const a = createAttempt(bank, config, [], "x", 1000),
      restored = JSON.parse(JSON.stringify(a));
    expect(restored.deadline).toBe(5401000);
    expect(expired(restored, 5401000)).toBe(true);
    expect(expired(restored, 2000)).toBe(false);
    const done = finish(restored, "expired", 5500000);
    expect(done.completedAt).toBe(5401000);
    expect(finish(done, "manual", 6000000)).toEqual(done);
  });
  it("luyện tập không có deadline", () => {
    const a = createAttempt(
      bank,
      { ...config, mode: "practice" },
      [],
      "x",
      1000,
    );
    expect(a.deadline).toBeNull();
    expect(expired(a, Number.MAX_SAFE_INTEGER)).toBe(false);
  });
  it("cấu hình luyện tập vẫn phải xuất nhập và chia sẻ được", () => {
    expect(() =>
      createAttempt(bank, { ...config, mode: "practice", minutes: 0 }, []),
    ).toThrow("Thời gian");
  });
  it("thống kê chủ đề có tên trùng thuộc tính hệ thống không thay Object.prototype", () => {
    const a = createAttempt(bank, config, [], "topic");
    a.questions[0].topic = "__proto__";
    const groups = breakdown(a, "topic");
    expect(groups["__proto__"].total).toBe(1);
    expect(Object.keys(groups)).toContain("__proto__");
    expect(Object.prototype).not.toHaveProperty("total");
  });
  it("CSV nhập lại giữ phiên bản và liên kết cùng đề dù thứ tự thuộc tính khác", async () => {
    const raw = Papa.unparse(
      bank.map((q) => ({
        ...q,
        options: JSON.stringify(q.options),
        source: JSON.stringify(q.source),
        updates: "[]",
        clinicalCase: "",
        image: "",
      })),
    );
    const imported = (await parseBank(new File([raw], "bank.csv"))).questions;
    expect(fingerprint(imported)).toBe(fingerprint(bank));
    const a = createAttempt(bank, config, [], "csv-share");
    const decoded = decodeShare(sharePayload(a), imported);
    expect(
      selectQuestions(imported, decoded.config, decoded.seed).map((q) => [
        q.id,
        q.optionOrder,
      ]),
    ).toEqual(a.questions.map((q) => [q.id, q.optionOrder]));
    expect(canShare(a, imported)).toBe(true);
  });
  it("chia sẻ không có tên cá nhân, tái tạo đề chính xác", () => {
    const a = createAttempt(bank, config, [], "x", 1000),
      payload = sharePayload(a),
      decoded = decodeShare(payload, bank);
    expect(decoded.config.name).toBe("");
    expect(selectQuestions(bank, decoded.config, decoded.seed)).toEqual(
      a.questions,
    );
    expect(atob(payload)).not.toContain("Tên riêng");
  });
  it("chỉ chia sẻ đề có thể tái tạo đúng từ seed, từ chối đề ôn câu sai", () => {
    const a = createAttempt(bank, config, [], "share");
    expect(canShare(a, bank)).toBe(true);
    a.answers[a.questions[0].id] = a.questions[0].optionOrder.indexOf(
      (a.questions[0].correctAnswer + 1) % 4,
    );
    expect(canShare(wrongPractice(finish(a, "manual")), bank)).toBe(false);
  });
  it("liên kết lỗi/version khác phải bị từ chối", () => {
    const a = createAttempt(bank, config, [], "x");
    expect(() => decodeShare("bad!", bank)).toThrow();
    const edited = structuredClone(bank);
    edited[0].question = "changed";
    expect(() => decodeShare(sharePayload(a), edited)).toThrow("Phiên bản");
    expect(fingerprint(bank)).not.toEqual(fingerprint(edited));
  });
  it("ôn câu sai chỉ lấy câu sai và làm lại giữ đề gốc", () => {
    const a = createAttempt(bank, config, [], "x", 1000);
    const q = a.questions[0];
    a.answers[q.id] = q.optionOrder.indexOf((q.correctAnswer + 1) % 4);
    const done = finish(a, "manual", 2000),
      practice = wrongPractice(done, 3000);
    expect(practice.questions.map((x) => x.id)).toEqual([q.id]);
    expect(practice.deadline).toBeNull();
    expect(practice.answers).toEqual({});
    expect(retryAttempt(done, 3000).questions).toEqual(a.questions);
    expect(
      Object.values(breakdown(done, "difficulty")).reduce(
        (s, g) => s + g.total,
        0,
      ),
    ).toBe(20);
  });
  it("ưu tiên câu ít xuất hiện ở lượt gần đây", () => {
    const a = createAttempt(bank, config, [], "old");
    const seed = chooseSeed(bank, config, [a]);
    const ids = new Set(a.questions.map((q) => q.id));
    expect(
      selectQuestions(bank, config, seed).filter((q) => ids.has(q.id)).length,
    ).toBeLessThan(10);
  });
});
describe("Kiểm tra dữ liệu nhập và lưu trữ", () => {
  it("từ chối ID trùng, đáp án sai cấu trúc và câu ảnh thiếu case", () => {
    expect(() => validateQuestions([bank[0], bank[0]])).toThrow("trùng");
    expect(() =>
      validateQuestions([{ ...bank[0], correctAnswer: 4 }]),
    ).toThrow();
    expect(() =>
      validateQuestions([{ ...bank[0], image: { src: "images/x.png" } }]),
    ).toThrow();
  });
  it("cảnh báo câu trùng và giữ HTML là chuỗi văn bản", () => {
    const q = { ...bank[0], id: "OTHER" };
    expect(validateQuestions([bank[0], q]).warnings.length).toBe(1);
    expect(
      validateQuestions([{ ...bank[0], question: '<img onerror="alert(1)">' }])
        .questions[0].question,
    ).toContain("<img");
  });
  it("không nhận ID có thể khiến câu bỏ trống bị chấm sai", () => {
    for (const id of ["toString", "constructor", "__proto__"])
      expect(() => validateQuestions([{ ...bank[0], id }])).toThrow(
        "dành riêng",
      );
  });
  it("từ chối số thứ tự phương án dạng chuỗi và bộ lọc sai kiểu trong bản sao lưu", () => {
    const a = finish(createAttempt(bank, config, [], "types"), "manual");
    const stringOrder = structuredClone(a);
    Object.assign(stringOrder.questions[0], {
      optionOrder: ["0", "1", "2", "3"],
    });
    expect(() => validateAttempts([stringOrder])).toThrow("Thứ tự");
    for (const change of [
      { chapters: { length: 1 } },
      { subject: 7 },
      { grade: "4" },
    ])
      expect(() =>
        validateAttempts([{ ...a, config: { ...a.config, ...change } }]),
      ).toThrow();
  });
  it("nhập lịch sử không ghi đè bài đang làm hoặc bài đã nộp; bản dự phòng không mở lại bài đã nộp", async () => {
    const active = createAttempt(bank, config, [], "collision");
    active.answers[active.questions[0].id] = 2;
    await saveAttempt(active);
    const completed = finish(active, "manual");
    const fresh = finish(
      createAttempt(bank, config, [], "new-import"),
      "manual",
    );
    expect(await importAttempts([completed, fresh])).toEqual({
      imported: 1,
      skipped: 1,
    });
    expect(
      (await readState()).attempts.find((a) => a.id === active.id),
    ).toEqual(active);
    expect(await importAttempts([fresh])).toEqual({ imported: 0, skipped: 1 });
    await saveAttempt(completed);
    await expect(restoreAttempt(active)).rejects.toThrow("đã có");
    expect(
      (await readState()).attempts.find((a) => a.id === active.id),
    ).toEqual(completed);
    await deleteAttempt(active.id);
    await deleteAttempt(fresh.id);
  });
  it("sao lưu giữ snapshot và đáp án, từ chối phương án đảo sai", () => {
    const a = finish(
      createAttempt(bank, config, [], "backup", 1000),
      "manual",
      2000,
    );
    expect(validateAttempts(JSON.parse(JSON.stringify([a])))).toEqual([a]);
    a.questions[0].optionOrder = [0, 0, 1, 2];
    expect(() => validateAttempts([a])).toThrow("Thứ tự");
  });
  it("bản dự phòng đang làm giữ deadline và từ chối flags/cursor ngoài đề", () => {
    const a = createAttempt(bank, config, [], "backup", 1000);
    expect(validateAttempts([a], true)[0]).toEqual(a);
    expect(() => validateAttempts([a])).toThrow();
    expect(() => validateAttempts([{ ...a, current: 20 }], true)).toThrow();
    expect(() =>
      validateAttempts([{ ...a, flags: ["absent"] }], true),
    ).toThrow();
    expect(() => validateAttempts([{ ...a, deadline: 999 }], true)).toThrow();
  });
  it("IndexedDB lưu/khôi phục nguyên bài, flags và deadline", async () => {
    const a = createAttempt(bank, config, [], "save", 1000);
    a.answers[a.questions[0].id] = 2;
    a.flags = [a.questions[0].id];
    a.current = 4;
    await saveAttempt(a);
    const restored = (await readState()).attempts.find((x) => x.id === a.id);
    expect(restored).toEqual(a);
    await deleteAttempt(a.id);
    expect((await readState()).attempts.some((x) => x.id === a.id)).toBe(false);
  });
  it("ngân hàng cục bộ lưu riêng và có thể khôi phục gốc", async () => {
    await saveBank(bank);
    expect((await readState()).customBank).toEqual(bank);
    await resetBank();
    expect((await readState()).customBank).toBeUndefined();
  });
});
