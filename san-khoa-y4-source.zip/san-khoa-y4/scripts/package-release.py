from pathlib import Path
import zipfile, json

root=Path(__file__).resolve().parents[1]
blocked={'.git','node_modules','dist','.local-sources','.local-qa','test-results','playwright-report'}
blocked_files={'reports/browser-tests.json','scripts/extract_sources.py'}
source=root/'san-khoa-y4-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if p.is_file() and rel.as_posix() not in blocked_files and not p.name.startswith('author-') and not any(part in blocked for part in rel.parts) and p.suffix not in ('.zip','.tar','.tsbuildinfo') and p.name!='.DS_Store':
            z.write(p,Path('san-khoa-y4')/rel)
static=root/'san-khoa-y4-static.zip'
with zipfile.ZipFile(static,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((root/'dist').rglob('*')):
        if p.is_file():z.write(p,p.relative_to(root/'dist'))
print(json.dumps({'sourceBytes':source.stat().st_size,'staticBytes':static.stat().st_size}))
