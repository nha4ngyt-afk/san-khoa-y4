import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const root = path.resolve("dist");
function walk(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
}
const assets = walk(root)
  .map((p) => path.relative(root, p).replaceAll("\\", "/"))
  .filter((p) => p !== "sw.js");
const version = crypto
  .createHash("sha256")
  .update(
    assets
      .map((p) =>
        Buffer.concat([
          Buffer.from(p + "\n"),
          fs.readFileSync(path.join(root, p)),
        ]),
      )
      .reduce((a, b) => Buffer.concat([a, b]), Buffer.alloc(0)),
  )
  .digest("hex")
  .slice(0, 16);
fs.writeFileSync(
  path.join(root, "sw.js"),
  `const BASE=new URL('./',self.location.href);const PREFIX='san-khoa-y4-'+BASE.pathname+'-';const CACHE=PREFIX+'${version}';const ASSETS=${JSON.stringify(assets)};self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS.map(p=>new URL(p,BASE).href)))));self.addEventListener('activate',event=>event.waitUntil(Promise.all([caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))),self.clients.claim()])));self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==BASE.origin||!url.pathname.startsWith(BASE.pathname))return;event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));}return response;}).catch(()=>event.request.mode==='navigate'?caches.match(new URL('index.html',BASE).href):Response.error())));});`,
);
console.log(`Offline cache: ${assets.length} files, version ${version}`);
