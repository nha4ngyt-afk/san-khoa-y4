import a from "./bank-a.json";
import b from "./bank-b.json";
import c from "./bank-c.json";
import images from "./imaging.json";
import sources from "./sources.json";
import type { Question, SourceRecord } from "../types";
export const INITIAL_BANK = [...a, ...b, ...c, ...images] as Question[];
export const SOURCES = sources as SourceRecord[];
