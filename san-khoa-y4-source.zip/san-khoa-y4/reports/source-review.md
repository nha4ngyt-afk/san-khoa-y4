# Báo cáo nguồn và phạm vi ngân hàng Sản khoa Y4

Chốt dữ liệu ngày 11/10/2026. Báo cáo tổng hợp ghi chú biên soạn A/B/C và tính lại trên bốn tệp câu hỏi đã khóa. Đây là hồ sơ rà soát của nhóm biên soạn; ngân hàng chưa được giảng viên hoặc bác sĩ chuyên khoa xác nhận và độ khó chưa được đo bằng kết quả làm bài thực tế.

## Quy mô và cấu trúc

Ngân hàng có **900 câu**: 294 câu A, 300 câu B, 300 câu C và 6 câu gắn hình ảnh. Phân bố **90 nhận biết, 135 thông hiểu, 360 vận dụng, 315 vận dụng cao**, tương ứng **10% / 15% / 40% / 35%**. Hai mức vận dụng chiếm 75%. Toàn bộ 675 câu ở hai mức này có bệnh cảnh luyện tập; một câu ảnh mức thông hiểu cũng có bệnh cảnh, nên tổng cộng 676 câu có tình huống.

| Chủ đề | Số câu |
|---|---:|
| Thai kỳ sớm | 115 |
| Chăm sóc và quản lý nửa đầu thai kỳ | 185 |
| Lượng giá sức khỏe thai | 120 |
| Bệnh lý và quản lý nửa sau thai kỳ | 180 |
| Quản lý chuyển dạ | 100 |
| Cấp cứu Sản khoa | 100 |
| Chăm sóc mẹ và trẻ trong hậu sản | 100 |
| **Tổng** | **900** |

Phạm vi chính là Sản khoa. Các vấn đề Phụ khoa chỉ xuất hiện khi nằm trong tài liệu học và liên quan mục tiêu của ngân hàng này. Bệnh cảnh ghi “Tình huống luyện tập” là giả định phục vụ học tập, không phải hồ sơ người bệnh thật hoặc khóa đáp án chính thức của bộ môn.

## Kiểm kê và độ phủ nguồn

Hai thư mục học có **145 tệp: 107 PDF, 18 DOCX và 20 bộ slide** (18 PPSX, 2 PPTX). Tham chiếu chính dùng mã tài liệu và trang/slide/đoạn để người học đối chiếu bản đang có; báo cáo không sao chép toàn văn hoặc công khai đường dẫn riêng trên thiết bị.

| Phần | Câu | Tệp trong kiểm kê có tham chiếu trực tiếp |
|---|---:|---:|
| A | 294 | 43 |
| B | 300 | 31 |
| C | 300 | 48 |
| Câu ảnh I | 6 | 2, đã nằm trong 43 nguồn A |
| **Tổng nguồn riêng biệt** | **900** | **122/145 (84,1%)** |

Các tập nguồn A/B/C trong bản khóa không giao nhau; sáu câu ảnh tham chiếu kiến thức từ hai bài học đã được phần A dùng. Hai bài JETem cung cấp ảnh được ghi riêng bằng liên kết và credit, không được cộng vào con số 145 tài liệu học. Có **23 tệp chưa được dùng làm tham chiếu chính của câu**. Nhiều tệp là ELO, bài tập đồng hành hoặc bản tổng hợp trùng mục tiêu với bài đầy đủ; chưa trích trực tiếp không đồng nghĩa bỏ qua toàn bộ nội dung. Độ phủ tham chiếu cũng không chứng minh rằng mọi trang, âm thanh hay ảnh nhúng trong 145 tệp đã được đọc đầy đủ.

| ID | Tệp chưa có tham chiếu trực tiếp trong bản khóa |
|---|---|
| Se5cb43f743 | ELOs Topic 41.pdf |
| S360a81f002 | ELOs Topic 42.pdf |
| S6c49dd2c00 | ELOs Topic 43.pdf |
| Sfa16ea042e | ELOs Topic 44.pdf |
| S68ff6d70d4 | ELOs Topic 45.pdf |
| Sf92f6b78a3 | ELOs Topic 46.pdf |
| Sdc58df376a | ELOs Topic 47.pdf |
| Sd982ee3202 | PBL 41 I'm looking at my past.pdf |
| Se995356c85 | Broken heart.pdf |
| Sa6e8af42bc | PBL 43 Tell me please revised 2021.pdf |
| S293cfcbc0c | Bài PBL 45 Death the story.pdf |
| Sdae8f367c2 | Mini-lecture (powerpoint audio) của chủ đề 3.ppsx |
| S183b6143fd | Topic 43 wrap-up.pdf |
| Sef820dc8e5 | Mini-lecture 44 (2022).ppsx |
| S82e7bf9f69 | Topic 44 Take home messages.pdf |
| Sd7f7e5ecb5 | Mini-lecture 45 (2022).ppsx |
| Sf55868b6f7 | CĐ 5 QL CD.pptx |
| Sbe89a7edc7 | Virtual training on clinical Obstetrics Case 3 Student version.ppsx |
| S144a1e4ac2 | Virtual training on clinical Obstetrics Case 4 Student version.ppsx |
| Sb908a32bd3 | Virtual training on clinical Obstetrics Case 6 Student version.ppsx |
| Sb3f83ea605 | Virtual training on clinical Obstetrics Case 7.ppsx |
| S865289e166 | Virtual training on clinical Obstetrics Case 8 Student version.ppsx |
| Seee839b21b | 00.-Các-vấn-đề-tư-vấn.docx |

ELO41–47 được đối chiếu theo mục tiêu; đáp án chuyên môn được dẫn về bài chi tiết. Các bản PBL/mini-lecture/take-home được dùng để kiểm phạm vi hoặc đối chiếu nội dung lặp. Không tạo thêm câu chỉ để mỗi tệp có một mã tham chiếu. Với CASE3/4/6/8, đã kiểm mục tiêu/bối cảnh, nhưng không coi mọi ảnh hoặc câu hỏi mở của slide là đã có khóa đáp án được xác nhận. CASE7 còn ảnh biểu đồ tăng trưởng không có dữ kiện OCR đủ tin cậy; phần nguyên lý được phủ, chưa khẳng định đã diễn giải đầy đủ các ảnh này.

**Nguồn scan Rhesus:** `S3c67584d03` (05 Rhesus âm) không có văn bản trích xuất hữu ích. Người soạn đã xem năm mảnh ảnh của trang PDF 3, dùng các nhánh đọc được về Rh cha, Coombs gián tiếp, anti-D, chưa mẫn cảm/đã mẫn cảm cho 10 câu. Không dùng liều hoặc thời điểm thiếu chắc chắn và không khẳng định đã đọc toàn bộ PDF.

## Sáu câu có ảnh

I001–I003 dùng một ảnh siêu âm thai ngoài tử cung; I004–I006 dùng một ảnh siêu âm nghi thai trứng. **Sáu câu tương ứng hai ảnh độc lập**, mỗi câu đều có bệnh cảnh cụ thể, hình đi kèm và đề bài. Ảnh giữ nguyên, có credit tác giả, nguồn và giấy phép **CC BY 4.0** được ghi trên trang xuất bản: [Farhat, Hoffmann, Alvarado — thai ngoài tử cung, JETem 2017](https://jetem.org/ectopic_pregnancy/) và [Wietecha, Williams, Slane — thai trứng, JETem 2022](https://jetem.org/molar/).

Phạm vi ảnh hiện tại còn hẹp ở hai chủ đề quý một. Không có tuyên bố đã xây đủ câu đọc ảnh cho toàn bộ siêu âm Sản khoa, Doppler, CTG hoặc MRI. Các câu khác có thể sử dụng thông số/báo cáo mô tả bằng chữ hoặc số để suy luận lâm sàng; chúng không được tính là câu đọc ảnh. Quyền dùng hai ảnh JETem không mở rộng sang hình trong mọi tài liệu học hoặc mọi website y khoa.

## Cách xử lý khác biệt giữa bài học và guideline

Theo lựa chọn đã được duyệt, **tài liệu học được ưu tiên cho ôn thi; cập nhật guideline được tách riêng trong lời giải**. Khi kiểm kiến thức lịch sử hoặc quy trình của một phiên bản bài, đề nêu phạm vi đó. Với lỗi rõ, mâu thuẫn nội bộ hoặc khuyến cáo cũ không phù hợp để áp dụng, nhóm chọn đoạn nhất quán/có căn cứ, thu hẹp mục tiêu hoặc bỏ chi tiết khỏi đáp án; không âm thầm đổi sang một đáp án mới mà thiếu giải thích. Có 46 câu có trường cập nhật từ nguồn chính thức, nhưng đây không phải cập nhật đầy đủ mọi chi tiết điều trị trong toàn ngân hàng.

Những vấn đề chính đã được xử lý trong biên soạn:

- **Thai sớm/di truyền/nhiễm trùng:** tránh bảng định tuổi và mô tả tăng hCG không nhất quán; không chốt vị trí/sinh tồn bằng một hCG; không dùng dòng liều MTX thiếu đơn vị. Phân loại thuốc A–X được nhận diện là lịch sử; các khác biệt EPL, cfDNA song thai, tỷ lệ mất thai thủ thuật, Rubella/CMV, HBV/HIV và thiếu máu được giới hạn hoặc chú giải.
- **Lượng giá thai/GDM:** xử lý bảng NST đảo nhóm tuổi; phân biệt OGTT 75 g một bước với đoạn DOCX yêu cầu hai trị số; không dùng phát biểu cấm OGTT sau 28 tuần làm đáp án. Theo dõi GDM hậu sản và cách gọi FGR được ghi theo nguồn/phiên bản, có cập nhật khi khác.
- **Sinh non/PPROM/THA:** không đưa 17-OHPC, nifedipine ngậm dưới lưỡi, bất động tuyệt đối hoặc dụng cụ giữ lưỡi khi giật thành xử trí đúng mặc định. Ngưỡng MgSO4 không nhất quán và đơn vị nghi lỗi được tránh; mục tiêu bảo vệ thần kinh thai tách với chống giật mẹ. Nitrazine được trình bày cùng giới hạn và khác biệt với NICE.
- **Chuyển dạ/cấp cứu:** sản đồ WHO 1993 được gọi rõ là model lịch sử; tránh oxy mẹ thường quy khi không thiếu oxy, các liều/nhịp hồi sức sơ sinh cũ và phác đồ thuyên tắc ối thiếu phù hợp. Không chờ đủ một ngưỡng máu ước tính khi đã có sốc, không chọn đường sanh chỉ từ một yếu tố đơn độc hoặc chỉ từ sẹo da.
- **Hậu sản:** tránh hút cạn/xoa bóp vú sâu mạnh, đồng nhất mọi viêm với nhiễm khuẩn, các ô bảng tránh thai mơ hồ, cấm thuốc cho bú tuyệt đối và ngưỡng bilirubin cố định cho mọi trẻ. Các cập nhật WHO, NICE, AHA/AAP, ABM và MEC được tách riêng ở câu liên quan.

Các chi tiết đã được tránh/chú giải vẫn tồn tại trong bản tài liệu gốc của người học; việc biên soạn không sửa nguyên bản hoặc xác nhận mọi nội dung của bản gốc là hiện hành.

## Các câu ưu tiên rà học thuật

Các ID dưới đây hiện có đáp án và lời giải; đây là thứ tự cần chú ý khi giảng viên/chuyên gia rà, không phải danh sách lỗi cấu trúc hoặc câu bị bỏ đáp án.

| 13 câu được phần A đánh dấu | Lý do cần chú ý |
|---|---|
| A037 | Ngưỡng CRL và quy trình xác minh sinh tồn; tránh can thiệp từ một lần đo. |
| A044 | Phân biệt thai lưu/sẩy không trọn khi đọc cập nhật mifepristone. |
| A046 | Tiêu chí theo dõi TNTC theo bài có thể khác phác đồ hiện hành. |
| A047 | Chọn MTX cần chẩn đoán và toàn bộ chống chỉ định, không thay bảng kiểm cơ sở. |
| A080 | Thai dị vị sau IVF, lựa chọn điều trị khi giữ thai trong tử cung. |
| A150 | Rubella IgM/IgG và vai trò xác minh theo CDC. |
| A153 | Giải mẫn cảm penicillin, phân loại giang mai và phạm vi phác đồ. |
| A166 | Chẩn đoán di truyền khi có bất thường cấu trúc dù NIPT thấp. |
| A172 | Khảm giới hạn ở nhau và kế hoạch xác minh/tư vấn. |
| A183 | Avidity/IgM Rubella ở người không triệu chứng, giới hạn xét nghiệm. |
| A184 | Nhiễm CMV mẹ gần đây không tương đương xác nhận nhiễm thai. |
| A279 | Nguy cơ Hb Bart’s với người bố hiện tại khác cặp của thai trước. |
| A284 | Coombs dương với kháng thể khác anti-D: cần đánh giá riêng ý nghĩa kháng thể. |

Phần B/C không có tệp xếp hạng ưu tiên riêng. Từ ghi chú biên soạn, các nhóm đã có khác biệt nguồn/cập nhật cần đặc biệt xem lại là:

| Nhóm câu | Điểm rà chính |
|---|---|
| B023; B056 | Thuật ngữ FGR và tiêu chí NST theo tuổi thai. |
| B205/B207/B208/B214; B222/B225 | Quy trình GDM, chọn thuốc, thời điểm khảo sát hậu sản. |
| B268/B272/B273; B280 | Đối tượng dự phòng sinh non, steroid nhắc, MgSO4 bảo vệ thần kinh. |
| B284/B291/B295 | Giới hạn test PPROM và thứ tự đánh giá tình trạng thai. |
| C024–C028; C038/C066 | Sản đồ lịch sử; tăng co/tụt áp và cập nhật theo dõi tim thai. |
| C088/C096–C099; C109/C119/C124 | Hồi sức sơ sinh và nhận diện/hồi sức BHSS. |
| C245/C250/C252; C262/C265/C269 | Phổ bệnh vú và bảng MEC 2015 so với cập nhật. |
| C276–C278; C290/C294/C295 | Dự phòng HBV khi cho bú và phạm vi hướng dẫn vàng da. |

## Giới hạn còn lại và kiểm tra đã hoàn thành

- Chưa có thẩm định độc lập chuyên khoa hoặc đo độ khó/sức phân biệt; nhãn bốn mức là phân loại của người soạn. Câu xử trí, ngưỡng xét nghiệm, thuốc và tư vấn di truyền cần đối chiếu chuẩn môn học/quy trình cơ sở khi dùng ngoài ôn tập.
- Chưa xem đầy đủ mọi ảnh nhúng, biểu đồ xét nghiệm, âm thanh slide hoặc mọi trang scan. Việc kiểm nguồn/locator tồn tại không thay kiểm chứng đầy đủ nội dung y khoa của từng trang.
- 23 tệp chưa có câu trích trực tiếp; độ phủ mục tiêu được đối chiếu với nguồn chi tiết và bản tổng hợp, không có tuyên bố đã khai thác hết mọi nội dung của 145 tệp.
- Sáu câu ảnh dùng hai tài sản được cấp phép; tính đa dạng hình ảnh còn hạn chế. Các kỹ năng thủ thuật và OSCE vẫn cần thực hành có giám sát.
- Đã hoàn thành kiểm cấu trúc: tổng câu/phân bố, ID, bốn lựa chọn, chỉ số đáp án, bệnh cảnh bắt buộc, nguồn và locator. Các phần đều ghi nhận không có lỗi cấu trúc chưa giải quyết; đã rà các nhiễu và tình huống, cùng loại mục tiêu lặp trước khi chốt 900 câu. Kiểm tra phần mềm và việc câu có một đáp án được người soạn chọn không phải chứng nhận độ chính xác chuyên khoa.

Bản này ghi phạm vi và giới hạn của ngân hàng tại thời điểm khóa, không gắn nhãn “chuyên gia đã duyệt”.
