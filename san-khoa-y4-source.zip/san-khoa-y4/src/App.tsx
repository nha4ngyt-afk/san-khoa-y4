import { useState, useEffect, useRef, type ReactNode } from "react";
import {
  Activity,
  ArrowRight,
  ArrowLeft,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Download,
  Flag,
  History,
  Home,
  Image as ImageIcon,
  LayoutGrid,
  Menu,
  Moon,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sun,
  Target,
  Trash2,
  Upload,
  X,
  BarChart3,
  RefreshCw,
  Share2,
  FileText,
  HeartPulse,
  Sprout,
  Stethoscope,
  Waves,
  ShieldPlus,
  Baby,
  Bookmark,
  AlertCircle,
  Maximize2,
  MoreHorizontal,
  FileCheck2,
} from "lucide-react";
import type { Attempt, ExamConfig, Question } from "./types";
import { DEFAULT_CONFIG, LEVELS, TOPICS } from "./types";
import { INITIAL_BANK, SOURCES } from "./data";
import {
  availability,
  quotas,
  createAttempt,
  expired,
  finish,
  grade,
  breakdown,
  filterBank,
  sharePayload,
  decodeShare,
  retryAttempt,
  wrongPractice,
  fingerprint,
  canShare,
} from "./core/engine";
import * as storage from "./core/storage";
import {
  download,
  exportBank,
  parseBank,
  exportHistory,
  parseHistory,
  parseActiveBackup,
  FILE_LIMIT,
} from "./core/files";
import { validateQuestions } from "./core/validation";
import { RichText } from "./components/RichText";
type View =
  | "home"
  | "topics"
  | "create"
  | "exam"
  | "result"
  | "bank"
  | "history"
  | "stats"
  | "settings"
  | "sources";
const icons = {
  BookOpen,
  Sprout,
  HeartPulse,
  Activity,
  Stethoscope,
  Waves,
  ShieldPlus,
  Baby,
};
const nav = [
  { id: "home", label: "Trang chủ", icon: Home },
  { id: "topics", label: "Tất cả chủ đề", icon: LayoutGrid },
  { id: "create", label: "Tạo đề kiểm tra", icon: Plus },
  { id: "bank", label: "Ngân hàng câu hỏi", icon: BookOpen },
  { id: "history", label: "Lịch sử làm bài", icon: History },
  { id: "stats", label: "Thống kê kết quả", icon: BarChart3 },
];
const getView = (): View => {
  const id = location.hash.slice(1).split("?")[0];
  return [
    ...nav.map((n) => n.id),
    "exam",
    "result",
    "settings",
    "sources",
  ].includes(id)
    ? (id as View)
    : "home";
};
const topicTitle = (id: string) => TOPICS.find((t) => t.id === id)?.title || id;
const date = (time: number) =>
  new Date(time).toLocaleString("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
const timeLabel = (ms: number) => {
  const n = Math.max(0, Math.ceil(ms / 1000));
  return [Math.floor(n / 3600), Math.floor((n % 3600) / 60), n % 60]
    .map((v) => String(v).padStart(2, "0"))
    .join(":");
};
const base = import.meta.env.BASE_URL;
function Badge({
  children,
  kind = "",
}: {
  children: ReactNode;
  kind?: string;
}) {
  return <span className={"badge " + kind}>{children}</span>;
}
function Empty({
  icon: Icon = BookOpen,
  title,
  children,
  action,
}: {
  icon?: typeof BookOpen;
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <div className="empty-icon">
        <Icon size={30} />
      </div>
      <h3>{title}</h3>
      <p>{children}</p>
      {action}
    </div>
  );
}
function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const prev = document.activeElement as HTMLElement;
    ref.current?.focus();
    const listener = (e: KeyboardEvent) => {
      if (
        document
          .querySelectorAll(".modal")
          .item(document.querySelectorAll(".modal").length - 1) !== ref.current
      )
        return;
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab") {
        const items = ref.current?.querySelectorAll<HTMLElement>(
          "button,input,textarea,select,a[href]",
        );
        if (!items?.length) return;
        const first = items[0],
          last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
      prev?.focus();
    };
  }, []);
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className={"modal " + (wide ? "wide" : "")}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={ref}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-title">
          <h2>{title}</h2>
          <button className="icon-button" aria-label="Đóng" onClick={onClose}>
            <X />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState(location.hash),
    [view, setView] = useState<View>(getView),
    [bank, setBank] = useState<Question[]>(INITIAL_BANK),
    [attempts, setAttempts] = useState<Attempt[]>([]),
    [selected, setSelected] = useState<string>(),
    [loaded, setLoaded] = useState(false),
    [theme, setTheme] = useState("light"),
    [menu, setMenu] = useState(false),
    [search, setSearch] = useState(""),
    [chip, setChip] = useState("all"),
    [config, setConfig] = useState<ExamConfig>({ ...DEFAULT_CONFIG }),
    [seed, setSeed] = useState<string>(),
    [shared, setShared] = useState(false),
    [saveStatus, setSaveStatus] = useState(""),
    [toast, setToast] = useState(""),
    [error, setError] = useState(""),
    [confirm, setConfirm] = useState<{
      title: string;
      text: string;
      action: () => void;
    } | null>(null),
    [editor, setEditor] = useState<Question | null | undefined>(undefined),
    [inspect, setInspect] = useState<Question | null>(null),
    [zoom, setZoom] = useState<Question | null>(null),
    [bankPage, setBankPage] = useState(1),
    [levelFilter, setLevelFilter] = useState("all"),
    [readerText, setReaderText] = useState(""),
    [readerBusy, setReaderBusy] = useState(false),
    [now, setNow] = useState(Date.now());
  const writes = useRef(Promise.resolve()),
    writeVersion = useRef(0),
    unsaved = useRef(false),
    openingAttempt = useRef(false),
    latest = useRef<Attempt | undefined>(undefined),
    toastTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const active = attempts.find((a) => a.status === "active"),
    current = attempts.find((a) => a.id === selected) || active;
  latest.current = active;
  const history = attempts
    .filter((a) => a.status === "completed")
    .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0));
  const topicCatalog = [
    ...new Set(
      bank
        .filter(
          (q) =>
            (!config.subject || q.subject === config.subject) &&
            (!config.grade || q.grade === config.grade),
        )
        .map((q) => q.topic),
    ),
  ].map(
    (id) =>
      TOPICS.find((t) => t.id === id) || {
        id,
        title: bank.find((q) => q.topic === id)?.chapter || id,
        short: id,
        description: "Ôn tập các bài học trong chủ đề.",
        color: "#dceee9",
        icon: "BookOpen",
      },
  );
  function notify(message: string) {
    setToast(message);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 4500);
  }
  function navigate(to: View) {
    location.hash = to;
    setView(to);
    setMenu(false);
    setSearch("");
    window.scrollTo({ top: 0 });
  }
  useEffect(() => {
    const listener = () => {
      setRoute(location.hash);
      setView(getView());
      setMenu(false);
    };
    window.addEventListener("hashchange", listener);
    return () => window.removeEventListener("hashchange", listener);
  }, []);
  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const state = await storage.readState();
        if (!live) return;
        let restored = state.attempts;
        const closed = restored.filter((a) => expired(a));
        for (const a of closed) {
          const result = finish(a, "expired");
          await storage.saveAttempt(result);
          restored = restored.map((x) => (x.id === a.id ? result : x));
        }
        setAttempts(restored);
        if (state.customBank) {
          validateQuestions(state.customBank);
          setBank(state.customBank);
        }
        if (state.theme) setTheme(state.theme);
        const ongoing = restored.find((a) => a.status === "active");
        if (ongoing) {
          setSelected(ongoing.id);
          setSaveStatus("Đã khôi phục bài làm");
        } else if (closed.length) {
          setSelected(closed[0].id);
          setView("result");
          location.hash = "result";
          setToast("Bài đã quá hạn và được tự động hoàn tất.");
        } else if (getView() === "exam" || getView() === "result") {
          setView("home");
          location.hash = "home";
        }
      } catch (e) {
        setError("Không thể đọc dữ liệu lưu trữ. " + String(e));
      } finally {
        if (live) setLoaded(true);
      }
    })();
    return () => {
      live = false;
    };
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", theme === "dark" ? "#121d25" : "#087e75");
  }, [theme]);
  useEffect(() => {
    if (!loaded) return;
    const params = new URLSearchParams(location.hash.split("?")[1] || "");
    const payload = params.get("exam");
    if (payload) {
      try {
        const decoded = decodeShare(payload, bank);
        setConfig(decoded.config);
        setSeed(decoded.seed);
        setShared(true);
        setView("create");
      } catch (e) {
        setError((e as Error).message);
        setShared(false);
      }
    }
  }, [loaded, route]);
  function write(a: Attempt) {
    const version = ++writeVersion.current;
    unsaved.current = true;
    setSaveStatus("Đang lưu…");
    writes.current = writes.current
      .catch(() => {})
      .then(async () => {
        await storage.saveAttempt(a);
        if (version === writeVersion.current) {
          unsaved.current = false;
          setSaveStatus("Đã lưu trên thiết bị");
        }
      })
      .catch((e) => {
        if (version === writeVersion.current)
          setSaveStatus("Lưu chưa thành công");
        setError(
          "Không lưu được bài làm. Hãy xuất lịch sử nếu đã nộp bài, hoặc bản dự phòng nếu đang làm, trước khi đóng trang. " +
            String(e),
        );
      });
    return writes.current;
  }
  function replace(a: Attempt) {
    if (a.status === "active") latest.current = a;
    else if (latest.current?.id === a.id) latest.current = undefined;
    setAttempts((prev) => {
      const found = prev.some((x) => x.id === a.id);
      return found ? prev.map((x) => (x.id === a.id ? a : x)) : [a, ...prev];
    });
    write(a);
  }
  function complete(a: Attempt, reason: "manual" | "expired") {
    const result = finish(a, reason);
    replace(result);
    setSelected(result.id);
    navigate("result");
    notify(
      reason === "expired"
        ? "Đã hết giờ. Bài làm được tự động hoàn tất."
        : "Đã hoàn thành bài kiểm tra.",
    );
  }
  useEffect(() => {
    const timer = setInterval(() => {
      const t = Date.now();
      const a = latest.current;
      if (a) setNow(t);
      if (a && expired(a, t)) complete(a, "expired");
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    const check = () => {
      const a = latest.current;
      if (a && expired(a)) complete(a, "expired");
    };
    document.addEventListener("visibilitychange", check);
    window.addEventListener("focus", check);
    return () => {
      document.removeEventListener("visibilitychange", check);
      window.removeEventListener("focus", check);
    };
  }, []);
  useEffect(() => {
    const listener = (e: BeforeUnloadEvent) => {
      if (unsaved.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", listener);
    return () => window.removeEventListener("beforeunload", listener);
  }, []);
  useEffect(() => {
    if (
      bank.length &&
      !bank.some(
        (q) =>
          (!config.subject || q.subject === config.subject) &&
          (!config.grade || q.grade === config.grade),
      )
    )
      setConfig((c) => ({
        ...c,
        subject: bank[0].subject,
        grade: bank[0].grade,
        chapters: [],
        topics: [],
        lessons: [],
      }));
  }, [bank]);
  useEffect(() => {
    setBankPage(1);
  }, [search, chip, levelFilter]);
  function editAnswer(index: number) {
    if (!current || current.status !== "active") return;
    if (expired(current)) {
      complete(current, "expired");
      return;
    }
    const q = current.questions[current.current];
    replace({ ...current, answers: { ...current.answers, [q.id]: index } });
  }
  function configure(topic?: string, mode: "exam" | "practice" = "exam") {
    setConfig({
      ...DEFAULT_CONFIG,
      subject: config.subject,
      grade: config.grade,
      name: config.name,
      topics: topic ? [topic] : [],
      mode,
    });
    setSeed(undefined);
    setShared(false);
    navigate("create");
  }
  async function start(a?: Attempt) {
    if (openingAttempt.current) return;
    const ongoing = latest.current;
    if (ongoing) {
      setConfirm({
        title: "Bạn có bài đang làm",
        text: "Hãy tiếp tục hoặc nộp bài đang làm trước khi bắt đầu bài mới.",
        action: () => {
          setSelected(ongoing.id);
          navigate("exam");
        },
      });
      return;
    }
    openingAttempt.current = true;
    try {
      const next = a || createAttempt(bank, config, history, seed);
      await storage.saveAttempt(next);
      latest.current = next;
      setNow(Date.now());
      setAttempts((prev) => [next, ...prev]);
      setSelected(next.id);
      setSaveStatus("Đã lưu trên thiết bị");
      setError("");
      navigate("exam");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      openingAttempt.current = false;
    }
  }
  async function persistBank(next: Question[]) {
    const checked = validateQuestions(next);
    await storage.saveBank(checked.questions);
    setBank(checked.questions);
    notify(
      checked.warnings.length
        ? `Đã lưu. ${checked.warnings.length} cảnh báo câu trùng nội dung.`
        : "Đã lưu ngân hàng trên thiết bị.",
    );
  }
  async function importBankFile(file: File) {
    try {
      const result = await parseBank(file);
      setConfirm({
        title: "Nhập ngân hàng câu hỏi",
        text: `Tệp có ${result.questions.length} câu. Nhập sẽ thay thế ngân hàng cục bộ. ${result.warnings.length ? result.warnings.length + " cảnh báo nội dung trùng." : ""} Bạn có thể xuất ngân hàng hiện tại trước khi tiếp tục.`,
        action: () => {
          persistBank(result.questions).catch((e) => setError(String(e)));
        },
      });
    } catch (e) {
      setError("Không thể nhập ngân hàng: " + (e as Error).message);
    }
  }
  async function importHistoryFile(file: File) {
    try {
      const data = await parseHistory(file);
      await writes.current;
      const result = await storage.importAttempts(data);
      const state = await storage.readState();
      setAttempts(state.attempts);
      notify(
        `Đã nhập ${result.imported} bài làm.${result.skipped ? ` Giữ nguyên ${result.skipped} bài đã có trên thiết bị.` : ""}`,
      );
    } catch (e) {
      setError("Không thể nhập lịch sử: " + (e as Error).message);
    }
  }
  async function restoreActive(file: File) {
    if (openingAttempt.current) return;
    openingAttempt.current = true;
    try {
      if (latest.current)
        throw new Error(
          "Hãy nộp hoặc tiếp tục bài đang làm trước khi nhập bản dự phòng khác.",
        );
      let a = await parseActiveBackup(file);
      await writes.current;
      if (attempts.some((existing) => existing.id === a.id))
        throw new Error(
          "Bài này đã có trên thiết bị. Bản dự phòng không thể ghi đè hoặc mở lại bài đã nộp.",
        );
      if (expired(a)) a = finish(a, "expired");
      await storage.restoreAttempt(a);
      latest.current = a.status === "active" ? a : undefined;
      setNow(Date.now());
      setAttempts((prev) => [a, ...prev.filter((x) => x.id !== a.id)]);
      setSelected(a.id);
      navigate(a.status === "active" ? "exam" : "result");
      setSaveStatus("Đã khôi phục bản dự phòng");
      notify(
        a.status === "active"
          ? "Đã khôi phục bài, giữ nguyên câu, đáp án và thời hạn."
          : "Bài trong bản dự phòng đã hết giờ và được hoàn tất.",
      );
    } catch (e) {
      setError("Không thể khôi phục bản dự phòng: " + (e as Error).message);
    } finally {
      openingAttempt.current = false;
    }
  }
  async function checkUpdate() {
    try {
      if (!("serviceWorker" in navigator)) {
        notify("Trình duyệt này chưa hỗ trợ tải website để dùng ngoại tuyến.");
        return;
      }
      const registration = await navigator.serviceWorker.getRegistration();
      if (!registration) {
        notify(
          "Website chưa tải xong bản ngoại tuyến. Hãy thử lại sau khi trang tải xong.",
        );
        return;
      }
      await registration.update();
      notify(
        registration.waiting
          ? "Có bản mới. Sau khi hoàn tất bài, đóng các tab website rồi mở lại để cập nhật."
          : registration.installing
            ? "Đang tải bản cập nhật. Bài đang làm vẫn được giữ nguyên."
            : "Đã kiểm tra bản cập nhật. Bài đang làm được giữ nguyên.",
      );
    } catch (e) {
      setError("Không kiểm tra được bản cập nhật. " + String(e));
    }
  }
  async function share(a: Attempt) {
    if (!canShare(a, bank)) {
      notify(
        "Đề này không thể tái tạo bằng liên kết với ngân hàng hiện tại. Hãy xuất lịch sử để giữ nguyên đề và kết quả.",
      );
      return;
    }
    const url = new URL(location.href);
    url.hash = "create?exam=" + encodeURIComponent(sharePayload(a));
    try {
      await navigator.clipboard.writeText(url.toString());
      notify("Đã sao chép liên kết cấu hình và seed của đề.");
    } catch {
      download("lien-ket-de.txt", url.toString(), "text/plain");
      notify("Liên kết đã được tải xuống tệp văn bản.");
    }
  }
  async function readDocument(file: File) {
    try {
      if (file.size > FILE_LIMIT)
        throw new Error("Tài liệu vượt giới hạn 25 MB.");
      setReaderBusy(true);
      if (/\.txt$/i.test(file.name)) setReaderText(await file.text());
      else if (/\.docx$/i.test(file.name)) {
        const mammoth = await import("mammoth");
        const result = await mammoth.extractRawText({
          arrayBuffer: await file.arrayBuffer(),
        });
        setReaderText(result.value);
      } else if (/\.pdf$/i.test(file.name)) {
        const pdfjs = await import("pdfjs-dist");
        const worker = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url"))
          .default;
        pdfjs.GlobalWorkerOptions.workerSrc = worker;
        const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() })
          .promise;
        if (doc.numPages > 500) {
          await doc.destroy();
          throw new Error("Chọn tài liệu có tối đa 500 trang.");
        }
        let text = "";
        for (let i = 1; i <= doc.numPages; i++) {
          const page = await doc.getPage(i);
          const content = await page.getTextContent();
          text +=
            `\n[Trang ${i}]\n` +
            content.items.map((x) => ("str" in x ? x.str : "")).join(" ") +
            "\n";
        }
        setReaderText(
          text.trim() ||
            "Tài liệu này không có lớp văn bản. Bạn có thể mở bản gốc để đọc ảnh hoặc bản scan.",
        );
        await doc.destroy();
      } else throw new Error("Chọn PDF, DOCX hoặc TXT.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setReaderBusy(false);
    }
  }
  const shownBank = bank.filter(
    (q) =>
      (chip === "all" || q.topic === chip) &&
      (levelFilter === "all" || q.difficulty === Number(levelFilter)) &&
      (q.question + " " + (q.clinicalCase || "") + " " + q.lesson + " " + q.id)
        .toLocaleLowerCase("vi")
        .includes(search.toLocaleLowerCase("vi")),
  );
  const visibleTopics = topicCatalog.filter(
    (t) =>
      (chip === "all" || t.id === chip) &&
      (t.title + " " + t.description)
        .toLocaleLowerCase("vi")
        .includes(search.toLocaleLowerCase("vi")),
  );
  const countByTopic = (id: string) =>
    bank.filter(
      (q) =>
        q.topic === id &&
        (!config.subject || q.subject === config.subject) &&
        (!config.grade || q.grade === config.grade),
    ).length;
  function TopicCard({ topic: t }: { topic: (typeof TOPICS)[number] }) {
    const Icon = icons[t.icon as keyof typeof icons];
    return (
      <button className="topic-card" onClick={() => configure(t.id)}>
        <div
          className={"topic-art art-" + t.id}
          style={{ backgroundColor: t.color }}
        >
          <span className="art-number">
            {String(topicCatalog.indexOf(t) + 1).padStart(2, "0")}
          </span>
          <div className="art-icon">
            <Icon size={62} strokeWidth={1.25} />
          </div>
          <span className="art-label">SẢN KHOA · Y4</span>
          <span className="art-tag">{countByTopic(t.id)} câu hỏi</span>
          <div className="art-orbit" />
        </div>
        <div className="card-info">
          <h3>{t.title}</h3>
          <p>{t.description}</p>
          <div className="card-footer">
            <span>
              <span className="tiny-dot" />4 mức độ
            </span>
            <span>
              Tạo đề <ArrowRight size={15} />
            </span>
          </div>
        </div>
      </button>
    );
  }
  if (!loaded)
    return (
      <div className="loading">
        <Activity className="spin" />
        <p>Đang khôi phục dữ liệu trên thiết bị…</p>
      </div>
    );
  const isExam = view === "exam" && current?.status === "active";
  return (
    <div className={"app " + (isExam ? "exam-layout" : "")}>
      <header className="topbar">
        <div className="brand-wrap">
          <button
            className="icon-button menu-toggle"
            aria-label="Mở menu"
            onClick={() => setMenu(!menu)}
          >
            <Menu size={21} />
          </button>
          <button className="brand" onClick={() => navigate("home")}>
            <span className="brand-symbol">
              <Activity size={24} />
            </span>
            <span>
              Sản khoa<span className="brand-y4">Y4</span>
            </span>
          </button>
        </div>
        <label className="global-search">
          <Search size={18} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={
              view === "bank"
                ? "Tìm câu hỏi, bài học hoặc ID…"
                : "Tìm chủ đề ôn tập…"
            }
            aria-label="Tìm kiếm"
          />
          <kbd>⌕</kbd>
        </label>
        <div className="top-actions">
          <button
            className="icon-button"
            aria-label={
              theme === "light"
                ? "Chuyển sang chế độ tối"
                : "Chuyển sang chế độ sáng"
            }
            onClick={() => {
              const next = theme === "light" ? "dark" : "light";
              setTheme(next);
              storage
                .setTheme(next)
                .catch(() => notify("Chưa lưu được cài đặt giao diện."));
            }}
          >
            {theme === "light" ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          <button
            className="button primary top-create"
            onClick={() => configure()}
          >
            <Plus size={17} />
            Tạo đề mới
          </button>
          <span className="avatar">Y4</span>
        </div>
      </header>
      {menu && (
        <div className="mobile-overlay" onClick={() => setMenu(false)} />
      )}
      <aside className={"sidebar " + (menu ? "open" : "")}>
        <p className="nav-caption">GÓC HỌC TẬP</p>
        <nav>
          {nav.map((n) => (
            <button
              key={n.id}
              className={"nav-item " + (view === n.id ? "active" : "")}
              onClick={() => navigate(n.id as View)}
            >
              <n.icon size={19} />
              <span>{n.label}</span>
              {n.id === "bank" && <small>{bank.length}</small>}
            </button>
          ))}
        </nav>
        <div className="sidebar-separator" />
        <p className="nav-caption">THƯ VIỆN CỦA BẠN</p>
        <button
          className={"nav-item " + (view === "sources" ? "active" : "")}
          onClick={() => navigate("sources")}
        >
          <FileText size={19} />
          Tài liệu tham chiếu
        </button>
        <button
          className={"nav-item " + (view === "settings" ? "active" : "")}
          onClick={() => navigate("settings")}
        >
          <Settings size={19} />
          Cài đặt & sao lưu
        </button>
        <div className="sidebar-bottom">
          <div className="local-label">
            <ShieldCheck size={17} />
            Dữ liệu lưu trên thiết bị
          </div>
          <p>
            Học theo nhịp của bạn.
            <br />
            Tiến bộ qua từng bài làm.
          </p>
          <span className="version">SẢN KHOA Y4 · 1.0</span>
        </div>
      </aside>
      <main className="main" id="main">
        <div className="content">
          {error && (
            <div className="alert error" role="alert">
              <AlertCircle size={19} />
              <span>{error}</span>
              <button
                className="icon-button"
                aria-label="Ẩn thông báo lỗi"
                onClick={() => setError("")}
              >
                <X size={17} />
              </button>
            </div>
          )}
          {(view === "home" || view === "topics") && (
            <>
              {view === "home" && (
                <>
                  <div className="greeting">
                    <span>KHÔNG GIAN ÔN TẬP CỦA BẠN</span>
                    <span className="small-local">
                      <ShieldCheck size={14} />
                      Lưu cục bộ
                    </span>
                  </div>
                  <section className="hero">
                    <div className="hero-copy">
                      <Badge kind="mint">
                        <span className="tiny-dot" />
                        Dành cho sinh viên Y khoa năm 4
                      </Badge>
                      <h1>
                        Vững kiến thức.
                        <br />
                        <span>Tự tin trước mỗi ca.</span>
                      </h1>
                      <p>
                        Ôn Sản khoa từ tài liệu của bạn. Tạo đề ngẫu nhiên,
                        <br className="desktop-break" /> phân tích kết quả và
                        luyện lại những câu cần nhớ.
                      </p>
                      <div className="hero-actions">
                        <button
                          className="button primary"
                          onClick={() => configure()}
                        >
                          <Plus size={18} />
                          Tạo đề kiểm tra
                          <ArrowRight size={17} />
                        </button>
                        <button
                          className="button ghost"
                          onClick={() => configure(undefined, "practice")}
                        >
                          Luyện tập tự do
                          <ChevronRight size={17} />
                        </button>
                      </div>
                    </div>
                    <div className="hero-illustration" aria-hidden="true">
                      <div className="hero-sheet">
                        <span className="sheet-category">
                          BÀI KIỂM TRA CỦA BẠN
                        </span>
                        <div className="sheet-title">
                          <FileCheck2 size={26} />
                          <span>Sản khoa tổng hợp</span>
                        </div>
                        <div className="sheet-line long" />
                        <div className="sheet-line" />
                        <div className="sheet-choice selected">
                          <span>
                            <Check size={13} />
                          </span>
                          <div />
                        </div>
                        <div className="sheet-choice">
                          <span />
                          <div />
                        </div>
                        <div className="sheet-choice">
                          <span />
                          <div />
                        </div>
                        <div className="sheet-meta">
                          <span>
                            <BookOpen size={14} />
                            90 câu
                          </span>
                          <span>
                            <Clock size={14} />
                            90 phút
                          </span>
                        </div>
                      </div>
                      <div className="floating-mark">
                        <ShieldCheck size={22} />
                        <span>
                          Có nguồn
                          <br />
                          <b>tham chiếu</b>
                        </span>
                      </div>
                      <div className="hero-circle" />
                    </div>
                  </section>
                  {active && (
                    <div className="resume-banner">
                      <div className="resume-icon">
                        <Bookmark size={22} />
                      </div>
                      <div>
                        <strong>Bạn có một bài đang làm</strong>
                        <p>
                          {Object.keys(active.answers).length}/
                          {active.questions.length} câu đã trả lời ·{" "}
                          {active.deadline
                            ? timeLabel(active.deadline - now)
                            : "Luyện tập không giới hạn"}
                        </p>
                      </div>
                      <button
                        className="button primary"
                        onClick={() => {
                          setSelected(active.id);
                          navigate("exam");
                        }}
                      >
                        Tiếp tục
                        <ArrowRight size={16} />
                      </button>
                    </div>
                  )}
                  <div className="overview">
                    <div>
                      <BookOpen size={21} />
                      <span>
                        <strong>{bank.length}</strong> câu hỏi trong ngân hàng
                      </span>
                    </div>
                    <div>
                      <LayoutGrid size={21} />
                      <span>
                        <strong>{topicCatalog.length}</strong> nhóm chủ đề
                      </span>
                    </div>
                    <div>
                      <Target size={21} />
                      <span>
                        <strong>{history.length}</strong> bài đã hoàn thành
                      </span>
                    </div>
                    <div>
                      <ImageIcon size={21} />
                      <span>
                        <strong>{bank.filter((q) => q.image).length}</strong>{" "}
                        câu có hình ảnh
                      </span>
                    </div>
                  </div>
                </>
              )}
              <div className="section-heading">
                <div>
                  <h2>
                    {view === "topics"
                      ? "Tất cả chủ đề"
                      : "Bạn muốn ôn gì hôm nay?"}
                  </h2>
                  <p>
                    Chọn một chủ đề hoặc kết hợp nhiều chủ đề trong cùng đề.
                  </p>
                </div>
                {view === "home" && (
                  <button
                    className="text-button"
                    onClick={() => navigate("topics")}
                  >
                    Xem tất cả
                    <ArrowRight size={16} />
                  </button>
                )}
              </div>
              <div className="chips">
                <button
                  className={chip === "all" ? "selected" : ""}
                  onClick={() => setChip("all")}
                >
                  Tất cả
                </button>
                {topicCatalog.map((t) => (
                  <button
                    key={t.id}
                    className={chip === t.id ? "selected" : ""}
                    onClick={() => setChip(t.id)}
                  >
                    {t.short}
                  </button>
                ))}
              </div>
              <div className="topic-grid">
                {visibleTopics.map((t) => (
                  <TopicCard key={t.id} topic={t} />
                ))}
              </div>
              {!visibleTopics.length && (
                <Empty title="Chưa tìm thấy chủ đề">
                  Thử tìm bằng tên chủ đề khác hoặc chọn “Tất cả”.
                </Empty>
              )}
              {view === "home" && (
                <section className="practice-strip">
                  <div className="practice-strip-icon">
                    <RefreshCw size={29} />
                  </div>
                  <div>
                    <h3>Học thêm từ những câu đã sai</h3>
                    <p>
                      Mở một bài trong lịch sử và chọn ôn câu sai để luyện lại.
                    </p>
                  </div>
                  <button
                    className="button secondary"
                    onClick={() => navigate("history")}
                  >
                    Mở lịch sử
                    <ArrowRight size={16} />
                  </button>
                </section>
              )}
            </>
          )}
          {view === "create" && (
            <>
              <PageIntro
                label="TẠO ĐỀ KIỂM TRA"
                title="Thiết kế lượt ôn của bạn"
                text="Chọn phạm vi và mức độ. Website sẽ rút câu hỏi phù hợp từ ngân hàng."
              />
              {shared && (
                <div className="alert info">
                  <Share2 size={19} />
                  <span>
                    Đề từ liên kết chia sẻ. Cấu hình và seed được giữ nguyên để
                    tái tạo cùng đề.
                  </span>
                  <button
                    className="text-button"
                    onClick={() => {
                      setShared(false);
                      setSeed(undefined);
                    }}
                  >
                    Tùy chỉnh đề riêng
                  </button>
                </div>
              )}
              <div className="configure-grid">
                <div className="panel">
                  <h3>
                    <SlidersHorizontal size={19} />
                    Thông tin bài kiểm tra
                  </h3>
                  {new Set(bank.map((q) => q.subject + "|" + q.grade)).size >
                    1 && (
                    <div className="field-grid">
                      <label className="field">
                        Môn học
                        <select
                          disabled={shared}
                          value={config.subject || ""}
                          onChange={(e) =>
                            setConfig({
                              ...config,
                              subject: e.target.value,
                              grade: bank.find(
                                (q) => q.subject === e.target.value,
                              )?.grade,
                              topics: [],
                              chapters: [],
                              lessons: [],
                            })
                          }
                        >
                          {[...new Set(bank.map((q) => q.subject))].map((s) => (
                            <option key={s}>{s}</option>
                          ))}
                        </select>
                      </label>
                      <label className="field">
                        Năm học
                        <select
                          disabled={shared}
                          value={config.grade || 4}
                          onChange={(e) =>
                            setConfig({
                              ...config,
                              grade: Number(e.target.value),
                              topics: [],
                              chapters: [],
                              lessons: [],
                            })
                          }
                        >
                          {[
                            ...new Set(
                              bank
                                .filter((q) => q.subject === config.subject)
                                .map((q) => q.grade),
                            ),
                          ]
                            .sort()
                            .map((g) => (
                              <option key={g} value={g}>
                                {g}
                              </option>
                            ))}
                        </select>
                      </label>
                    </div>
                  )}
                  <label className="field">
                    Tên người làm bài
                    <input
                      maxLength={100}
                      placeholder="Nhập tên của bạn (không bắt buộc)"
                      value={config.name}
                      onChange={(e) =>
                        setConfig({ ...config, name: e.target.value })
                      }
                    />
                  </label>
                  <div className="mode-picker">
                    <button
                      className={config.mode === "exam" ? "selected" : ""}
                      disabled={shared}
                      onClick={() => setConfig({ ...config, mode: "exam" })}
                    >
                      <Clock size={20} />
                      <strong>Kiểm tra có thời gian</strong>
                      <span>Tự hoàn tất khi hết giờ</span>
                    </button>
                    <button
                      className={config.mode === "practice" ? "selected" : ""}
                      disabled={shared}
                      onClick={() =>
                        setConfig({
                          ...config,
                          mode: "practice",
                          minutes:
                            Number.isFinite(config.minutes) &&
                            config.minutes >= 1 &&
                            config.minutes <= 1440
                              ? config.minutes
                              : DEFAULT_CONFIG.minutes,
                        })
                      }
                    >
                      <BookOpen size={20} />
                      <strong>Luyện tập tự do</strong>
                      <span>Không giới hạn thời gian</span>
                    </button>
                  </div>
                  <div className="field-grid">
                    <label className="field">
                      Số câu trắc nghiệm
                      <input
                        type="number"
                        min={1}
                        max={2000}
                        disabled={shared}
                        value={config.count}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            count: Number(e.target.value),
                          })
                        }
                      />
                    </label>
                    <label className="field">
                      Thời gian (phút)
                      <input
                        type="number"
                        min={1}
                        max={1440}
                        disabled={shared || config.mode === "practice"}
                        value={config.minutes}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            minutes: Number(e.target.value),
                          })
                        }
                      />
                    </label>
                  </div>
                  <label className="field">
                    Loại câu hỏi
                    <select
                      disabled={shared}
                      value={config.images}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          images: e.target.value as ExamConfig["images"],
                        })
                      }
                    >
                      <option value="all">Tất cả câu hỏi</option>
                      <option value="with">Chỉ câu có hình ảnh học</option>
                      <option value="without">Câu không có hình ảnh</option>
                    </select>
                  </label>
                </div>
                <div className="panel">
                  <h3>
                    <LayoutGrid size={19} />
                    Phạm vi kiến thức
                  </h3>
                  <p className="muted">
                    Để trống lựa chọn để dùng tất cả chủ đề.
                  </p>
                  <div className="topic-checks">
                    {topicCatalog.map((t) => (
                      <label key={t.id}>
                        <input
                          type="checkbox"
                          disabled={shared}
                          checked={config.topics.includes(t.id)}
                          onChange={(e) =>
                            setConfig({
                              ...config,
                              lessons: [],
                              topics: e.target.checked
                                ? [...config.topics, t.id]
                                : config.topics.filter((x) => x !== t.id),
                            })
                          }
                        />
                        <span>
                          {t.title}
                          <small>{countByTopic(t.id)} câu</small>
                        </span>
                      </label>
                    ))}
                  </div>
                  <label className="field">
                    Lọc theo bài học
                    <select
                      disabled={shared}
                      value={
                        config.lessons.length === 1 ? config.lessons[0] : ""
                      }
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          lessons: e.target.value ? [e.target.value] : [],
                        })
                      }
                    >
                      <option value="">Tất cả bài trong phạm vi</option>
                      {[
                        ...new Set(
                          filterBank(bank, { ...config, lessons: [] }).map(
                            (q) => q.lesson,
                          ),
                        ),
                      ]
                        .sort()
                        .map((l) => (
                          <option key={l}>{l}</option>
                        ))}
                    </select>
                  </label>
                </div>
                <div className="panel difficulty-panel">
                  <h3>
                    <Target size={19} />
                    Phân bố mức độ khó
                  </h3>
                  <div className="difficulty-fields">
                    {LEVELS.map((l, i) => (
                      <label
                        className={"difficulty-field level-" + (i + 1)}
                        key={l}
                      >
                        <span>{l}</span>
                        <div>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            step={1}
                            disabled={shared}
                            value={config.ratios[i]}
                            onChange={(e) =>
                              setConfig({
                                ...config,
                                ratios: config.ratios.map((x, j) =>
                                  j === i ? Number(e.target.value) : x,
                                ),
                              })
                            }
                          />
                          <span>%</span>
                        </div>
                        <small>
                          {availability(bank, config)[i]} câu khả dụng
                        </small>
                      </label>
                    ))}
                  </div>
                  <div className="ratio-total">
                    Tổng tỉ lệ{" "}
                    <strong
                      className={
                        config.ratios.reduce((a, b) => a + b, 0) === 100
                          ? "success-text"
                          : "danger-text"
                      }
                    >
                      {config.ratios.reduce((a, b) => a + b, 0)}%
                    </strong>
                    <button
                      disabled={shared}
                      className="text-button"
                      onClick={() =>
                        setConfig({ ...config, ratios: [10, 15, 40, 35] })
                      }
                    >
                      Dùng tỉ lệ đề xuất
                    </button>
                  </div>
                </div>
                <div className="panel exam-summary">
                  <h3>Đề của bạn</h3>
                  <div className="summary-count">
                    {config.count}
                    <span>câu trắc nghiệm</span>
                  </div>
                  <p>
                    <Clock size={16} />
                    {config.mode === "exam"
                      ? `${config.minutes} phút`
                      : "Không giới hạn thời gian"}
                  </p>
                  <p>
                    <LayoutGrid size={16} />
                    {config.topics.length ? config.topics.length : "Tất cả"} chủ
                    đề
                  </p>
                  <div className="quota-list">
                    {(() => {
                      try {
                        return quotas(config.count, config.ratios).map(
                          (n, i) => (
                            <div key={i}>
                              <span>{LEVELS[i]}</span>
                              <b>{n} câu</b>
                            </div>
                          ),
                        );
                      } catch {
                        return (
                          <span className="danger-text">
                            Kiểm tra số câu và tổng tỉ lệ.
                          </span>
                        );
                      }
                    })()}
                  </div>
                  <button
                    className="button primary large"
                    onClick={() => start()}
                  >
                    Bắt đầu làm bài
                    <ArrowRight size={19} />
                  </button>
                  <p className="summary-note">
                    <ShieldCheck size={15} />
                    Bài làm tự động lưu trên thiết bị này.
                  </p>
                </div>
              </div>
            </>
          )}
          {isExam && current && (
            <ExamView
              attempt={current}
              now={now}
              saveStatus={saveStatus}
              onAnswer={editAnswer}
              onMove={(i) => replace({ ...current, current: i })}
              onFlag={() => {
                const id = current.questions[current.current].id;
                replace({
                  ...current,
                  flags: current.flags.includes(id)
                    ? current.flags.filter((x) => x !== id)
                    : [...current.flags, id],
                });
              }}
              onZoom={setZoom}
              onSubmit={() =>
                setConfirm({
                  title: "Nộp bài kiểm tra?",
                  text: `Bạn đã trả lời ${Object.keys(current.answers).length}/${current.questions.length} câu. Sau khi nộp, bạn có thể xem đáp án và lời giải.`,
                  action: () =>
                    complete(current, expired(current) ? "expired" : "manual"),
                })
              }
            />
          )}
          {view === "exam" && !isExam && (
            <Empty
              title="Chưa có bài đang làm"
              action={
                <button className="button primary" onClick={() => configure()}>
                  Tạo đề mới
                </button>
              }
            >
              Tạo một đề hoặc mở lại bài đã lưu từ trang chủ.
            </Empty>
          )}
          {view === "result" && current?.status === "completed" && (
            <ResultView
              attempt={current}
              onZoom={setZoom}
              onShare={
                canShare(current, bank) ? () => share(current) : undefined
              }
              onWrong={() => {
                try {
                  start(wrongPractice(current));
                } catch (e) {
                  setError((e as Error).message);
                }
              }}
              onRetry={() => start(retryAttempt(current))}
              onNew={() => {
                setConfig(current.config);
                setShared(false);
                setSeed(undefined);
                navigate("create");
              }}
            />
          )}
          {view === "result" && current?.status !== "completed" && (
            <Empty title="Chưa có kết quả">
              Hoàn thành một bài kiểm tra để xem kết quả.
            </Empty>
          )}
          {view === "history" && (
            <>
              <PageIntro
                label="LỊCH SỬ LÀM BÀI"
                title="Nhìn lại từng lượt ôn"
                text="Các bài đã hoàn thành được lưu trên thiết bị và trình duyệt này."
              />
              <div className="toolbar">
                <span>{history.length} bài đã hoàn thành</span>
                <div>
                  <button
                    className="button secondary"
                    disabled={!history.length}
                    onClick={() => exportHistory(history)}
                  >
                    <Download size={16} />
                    Xuất JSON
                  </button>
                  <button
                    className="button secondary"
                    disabled={!history.length}
                    onClick={() => exportHistory(history, true)}
                  >
                    CSV
                  </button>
                  <label className="button secondary">
                    <Upload size={16} />
                    Nhập sao lưu
                    <input
                      className="file-input"
                      type="file"
                      accept=".json,.csv"
                      onChange={(e) => {
                        if (e.target.files?.[0])
                          importHistoryFile(e.target.files[0]);
                        e.target.value = "";
                      }}
                    />
                  </label>
                </div>
              </div>
              {history.length ? (
                <div className="history-list">
                  {history.map((a) => {
                    const r = grade(a);
                    return (
                      <article className="history-card" key={a.id}>
                        <div className="history-symbol">
                          <FileCheck2 size={25} />
                        </div>
                        <div className="history-info">
                          <h3>{a.config.name || "Lượt ôn Sản khoa"}</h3>
                          <p>
                            {date(a.completedAt!)} ·{" "}
                            {a.config.mode === "exam"
                              ? "Kiểm tra"
                              : "Luyện tập"}{" "}
                            ·{" "}
                            {a.config.topics.length
                              ? a.config.topics.map(topicTitle).join(", ")
                              : "Tổng hợp"}
                          </p>
                          <span className="muted">
                            {r.wrong} sai · {r.blank} bỏ trống
                          </span>
                        </div>
                        <div className="history-score">
                          <strong>
                            {r.correct}
                            <span>/{r.total}</span>
                          </strong>
                          <small>câu đúng</small>
                        </div>
                        <button
                          className="button secondary"
                          onClick={() => {
                            setSelected(a.id);
                            navigate("result");
                          }}
                        >
                          Xem lại
                          <ChevronRight size={15} />
                        </button>
                        <button
                          className="icon-button danger-text"
                          aria-label="Xóa bài làm"
                          onClick={() =>
                            setConfirm({
                              title: "Xóa bài làm?",
                              text: "Bài này sẽ được xóa khỏi lịch sử trên thiết bị.",
                              action: () => {
                                storage
                                  .deleteAttempt(a.id)
                                  .then(() =>
                                    setAttempts((prev) =>
                                      prev.filter((x) => x.id !== a.id),
                                    ),
                                  )
                                  .catch((e) => setError(String(e)));
                              },
                            })
                          }
                        >
                          <Trash2 size={18} />
                        </button>
                      </article>
                    );
                  })}
                </div>
              ) : (
                <Empty
                  icon={History}
                  title="Lịch sử bắt đầu từ bài đầu tiên"
                  action={
                    <button
                      className="button primary"
                      onClick={() => configure()}
                    >
                      Tạo đề kiểm tra
                      <ArrowRight size={16} />
                    </button>
                  }
                >
                  Sau khi hoàn tất bài, bạn có thể xem lại lời giải và luyện câu
                  sai tại đây.
                </Empty>
              )}
            </>
          )}
          {view === "stats" && (
            <>
              <PageIntro
                label="THỐNG KÊ KẾT QUẢ"
                title="Hiểu rõ phần cần ôn thêm"
                text="Thống kê chỉ dựa trên những bài bạn đã hoàn thành trên thiết bị."
              />
              {history.length ? (
                <>
                  <div className="stats-row">
                    <Stat
                      label="Bài đã hoàn thành"
                      value={String(history.length)}
                      icon={FileCheck2}
                    />
                    <Stat
                      label="Lượt câu đã làm"
                      value={String(
                        history.reduce(
                          (s, a) => s + Object.keys(a.answers).length,
                          0,
                        ),
                      )}
                      icon={BookOpen}
                    />
                    <Stat
                      label="Tổng lượt trả lời đúng"
                      value={String(
                        history.reduce((s, a) => s + grade(a).correct, 0),
                      )}
                      icon={CheckCircle2}
                    />
                  </div>
                  <div className="analysis-grid">
                    <div className="panel">
                      <h3>Kết quả theo chủ đề</h3>
                      <AggregateBars history={history} type="topic" />
                    </div>
                    <div className="panel">
                      <h3>Kết quả theo mức độ</h3>
                      <AggregateBars history={history} type="difficulty" />
                    </div>
                  </div>
                  <div className="panel">
                    <h3>Các lượt ôn gần đây</h3>
                    <div className="trend-list">
                      {history
                        .slice(0, 10)
                        .reverse()
                        .map((a) => (
                          <div key={a.id}>
                            <span>{date(a.completedAt!)}</span>
                            <div className="bar-track">
                              <div
                                style={{
                                  width:
                                    (grade(a).correct / grade(a).total) * 100 +
                                    "%",
                                }}
                              />
                            </div>
                            <b>
                              {grade(a).correct}/{grade(a).total}
                            </b>
                          </div>
                        ))}
                    </div>
                  </div>
                </>
              ) : (
                <Empty icon={BarChart3} title="Chưa có dữ liệu thống kê">
                  Hoàn thành một bài kiểm tra để xem mức độ và chủ đề cần ôn
                  thêm.
                </Empty>
              )}
            </>
          )}
          {view === "bank" && (
            <>
              <PageIntro
                label="NGÂN HÀNG CÂU HỎI"
                title="Kiến thức có nguồn tham chiếu"
                text="Xem, biên soạn và chỉnh sửa ngân hàng cục bộ trên thiết bị này."
              />
              <div className="toolbar">
                <span>
                  <strong>{shownBank.length}</strong>/{bank.length} câu hỏi
                </span>
                <div>
                  <button
                    className="button secondary"
                    onClick={() => exportBank(bank)}
                  >
                    <Download size={16} />
                    JSON
                  </button>
                  <button
                    className="button secondary"
                    onClick={() => exportBank(bank, true)}
                  >
                    CSV
                  </button>
                  <label className="button secondary">
                    <Upload size={16} />
                    Nhập
                    <input
                      className="file-input"
                      type="file"
                      accept=".json,.csv"
                      onChange={(e) => {
                        if (e.target.files?.[0])
                          importBankFile(e.target.files[0]);
                        e.target.value = "";
                      }}
                    />
                  </label>
                  <button
                    className="button primary"
                    onClick={() => setEditor(null)}
                  >
                    <Plus size={16} />
                    Thêm câu hỏi
                  </button>
                </div>
              </div>
              <div className="bank-filters">
                <select
                  aria-label="Lọc chủ đề"
                  value={chip}
                  onChange={(e) => setChip(e.target.value)}
                >
                  <option value="all">Tất cả chủ đề</option>
                  {topicCatalog.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
                </select>
                <select
                  aria-label="Lọc mức độ"
                  value={levelFilter}
                  onChange={(e) => setLevelFilter(e.target.value)}
                >
                  <option value="all">Tất cả mức độ</option>
                  {LEVELS.map((l, i) => (
                    <option value={i + 1} key={l}>
                      {l}
                    </option>
                  ))}
                </select>
                <span className="muted">
                  Dùng thanh tìm kiếm phía trên để tìm nội dung hoặc ID.
                </span>
              </div>
              <div className="bank-list">
                {shownBank
                  .slice((bankPage - 1) * 20, bankPage * 20)
                  .map((q) => (
                    <article className="bank-row" key={q.id}>
                      <div className="bank-row-meta">
                        <span>{q.id}</span>
                        <Badge kind={"level-" + q.difficulty}>
                          {LEVELS[q.difficulty - 1]}
                        </Badge>
                        {q.image && (
                          <Badge>
                            <ImageIcon size={12} />
                            Có ảnh
                          </Badge>
                        )}
                      </div>
                      <button
                        className="bank-question"
                        onClick={() => setInspect(q)}
                      >
                        <RichText text={q.question} />
                      </button>
                      <p>
                        {q.lesson} · {topicTitle(q.topic)}
                      </p>
                      <div className="bank-row-actions">
                        <button
                          className="text-button"
                          onClick={() => setInspect(q)}
                        >
                          Xem câu & đáp án
                        </button>
                        <button
                          className="text-button"
                          onClick={() => setEditor(q)}
                        >
                          Sửa
                        </button>
                        <button
                          className="text-button danger-text"
                          onClick={() =>
                            setConfirm({
                              title: "Xóa câu hỏi?",
                              text: `Xóa ${q.id} khỏi ngân hàng trên thiết bị. Bài làm cũ vẫn giữ nguyên câu đã lưu.`,
                              action: () =>
                                persistBank(
                                  bank.filter((x) => x.id !== q.id),
                                ).catch((e) => setError(String(e))),
                            })
                          }
                        >
                          Xóa
                        </button>
                      </div>
                    </article>
                  ))}
              </div>
              {!shownBank.length && (
                <Empty title="Chưa tìm thấy câu hỏi">
                  Thay đổi bộ lọc hoặc từ khóa tìm kiếm.
                </Empty>
              )}
              <div className="pagination">
                <button
                  className="button secondary"
                  disabled={bankPage <= 1}
                  onClick={() => setBankPage(bankPage - 1)}
                >
                  <ArrowLeft size={16} />
                  Trước
                </button>
                <span>
                  Trang {bankPage}/
                  {Math.max(1, Math.ceil(shownBank.length / 20))}
                </span>
                <button
                  className="button secondary"
                  disabled={bankPage * 20 >= shownBank.length}
                  onClick={() => setBankPage(bankPage + 1)}
                >
                  Sau
                  <ArrowRight size={16} />
                </button>
              </div>
            </>
          )}
          {view === "sources" && (
            <>
              <PageIntro
                label="TÀI LIỆU THAM CHIẾU"
                title="Nguồn học tập của ngân hàng"
                text="Danh mục nguồn dùng biên soạn. Tài liệu nguyên bản được giữ trên máy của bạn."
              />
              <div className="panel reader">
                <h3>
                  <FileText size={19} />
                  Đọc tài liệu trên thiết bị
                </h3>
                <p>
                  Chọn PDF, DOCX hoặc TXT để đọc văn bản tham khảo và biên soạn
                  câu hỏi. Tệp được xử lý trong trình duyệt.
                </p>
                <label className="button secondary">
                  <Upload size={17} />
                  {readerBusy ? "Đang đọc…" : "Chọn tài liệu"}
                  <input
                    disabled={readerBusy}
                    className="file-input"
                    type="file"
                    accept=".pdf,.docx,.txt"
                    onChange={(e) => {
                      if (e.target.files?.[0]) readDocument(e.target.files[0]);
                      e.target.value = "";
                    }}
                  />
                </label>
                {readerText && (
                  <>
                    <textarea
                      aria-label="Văn bản tài liệu"
                      readOnly
                      value={readerText}
                    />
                    <button
                      className="button secondary"
                      onClick={() => {
                        navigator.clipboard
                          .writeText(readerText)
                          .then(() => notify("Đã sao chép văn bản."))
                          .catch(() =>
                            setError(
                              "Không thể sao chép. Bạn có thể chọn văn bản trong khung.",
                            ),
                          );
                      }}
                    >
                      Sao chép văn bản
                    </button>
                    <button
                      className="text-button"
                      onClick={() => setReaderText("")}
                    >
                      Đóng tài liệu
                    </button>
                  </>
                )}
              </div>
              <div className="section-heading">
                <h2>{SOURCES.length} tài liệu nguồn</h2>
                <span className="muted">
                  {new Set(bank.map((q) => q.source.documentId)).size} nguồn
                  đang có câu hỏi
                </span>
              </div>
              <div className="source-list">
                {SOURCES.filter((s) =>
                  (s.title + " " + s.folder)
                    .toLocaleLowerCase("vi")
                    .includes(search.toLocaleLowerCase("vi")),
                ).map((s) => (
                  <div className="source-row" key={s.id}>
                    <FileText size={20} />
                    <div>
                      <strong>{s.title}</strong>
                      <p>
                        {s.collection} ·{" "}
                        {s.folder === "." ? "Tài liệu ôn thi" : s.folder}
                      </p>
                      <small>
                        {s.id} · {s.units} trang/đơn vị ·{" "}
                        {
                          bank.filter((q) => q.source.documentId === s.id)
                            .length
                        }{" "}
                        câu tham chiếu
                      </small>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
          {view === "settings" && (
            <>
              <PageIntro
                label="CÀI ĐẶT & SAO LƯU"
                title="Giữ lại dữ liệu học tập"
                text="Lịch sử và chỉnh sửa ngân hàng không tự đồng bộ giữa thiết bị hoặc trình duyệt."
              />
              <div className="settings-grid">
                <div className="panel">
                  <h3>
                    <Download size={20} />
                    Sao lưu dữ liệu
                  </h3>
                  <p>
                    Xuất JSON hoặc CSV rồi nhập trên thiết bị khác để chuyển
                    lịch sử thủ công. Ngân hàng có ảnh cần có các tệp ảnh tương
                    ứng trên website.
                  </p>
                  <div className="button-row">
                    <button
                      className="button secondary"
                      onClick={() => exportHistory(history)}
                    >
                      Xuất lịch sử JSON
                    </button>
                    <button
                      className="button secondary"
                      onClick={() => exportHistory(history, true)}
                    >
                      CSV
                    </button>
                    <label className="button secondary">
                      Nhập lịch sử
                      <input
                        className="file-input"
                        type="file"
                        accept=".json,.csv"
                        onChange={(e) => {
                          if (e.target.files?.[0])
                            importHistoryFile(e.target.files[0]);
                          e.target.value = "";
                        }}
                      />
                    </label>
                  </div>
                  <div className="button-row">
                    <button
                      className="button secondary"
                      onClick={() => exportBank(bank)}
                    >
                      Xuất ngân hàng JSON
                    </button>
                    <button
                      className="button secondary"
                      onClick={() => exportBank(bank, true)}
                    >
                      CSV
                    </button>
                  </div>
                  {active && (
                    <button
                      className="button secondary"
                      onClick={() =>
                        download(
                          "bai-dang-lam-du-phong.json",
                          JSON.stringify(
                            { schemaVersion: 1, activeAttempt: active },
                            null,
                            2,
                          ),
                        )
                      }
                    >
                      Xuất bản dự phòng bài đang làm
                    </button>
                  )}
                  <label className="button secondary">
                    Khôi phục bài từ bản dự phòng
                    <input
                      className="file-input"
                      type="file"
                      accept=".json"
                      onChange={(e) => {
                        if (e.target.files?.[0])
                          restoreActive(e.target.files[0]);
                        e.target.value = "";
                      }}
                    />
                  </label>
                </div>
                <div className="panel">
                  <h3>
                    <ShieldCheck size={20} />
                    Lưu trữ trên trình duyệt
                  </h3>
                  <p>
                    Bài làm, câu trả lời và lịch sử lưu bằng IndexedDB. Xóa dữ
                    liệu trình duyệt có thể xóa dữ liệu học tập; hãy sao lưu khi
                    cần.
                  </p>
                  <button
                    className="button secondary"
                    onClick={() => {
                      navigator.storage
                        ?.persist?.()
                        .then((ok) =>
                          notify(
                            ok
                              ? "Trình duyệt đã cấp lưu trữ bền vững."
                              : "Trình duyệt chưa cấp lưu trữ bền vững; bạn vẫn có thể sao lưu thủ công.",
                          ),
                        )
                        .catch(() =>
                          notify("Trình duyệt chưa hỗ trợ thao tác này."),
                        );
                    }}
                  >
                    Yêu cầu lưu trữ bền vững
                  </button>
                  <p className="small muted">
                    Phiên bản ngân hàng: {fingerprint(bank)}
                  </p>
                </div>
                <div className="panel">
                  <h3>
                    <RefreshCw size={20} />
                    Ngoại tuyến & cập nhật
                  </h3>
                  <p>
                    Website tải các tệp cần thiết khi bạn truy cập. Sau khi tải
                    xong, bạn có thể mở lại và làm bài ngoại tuyến. Lần tải đầu
                    cần kết nối Internet.
                  </p>
                  <button className="button secondary" onClick={checkUpdate}>
                    Kiểm tra cập nhật
                  </button>
                </div>
                <div className="panel">
                  <h3>
                    <Trash2 size={20} />
                    Quản lý dữ liệu cục bộ
                  </h3>
                  <p>
                    Ngân hàng chung được cập nhật bằng cách chỉnh dữ liệu trong
                    dự án và triển khai lại website.
                  </p>
                  <div className="button-row">
                    <button
                      className="button secondary"
                      onClick={() =>
                        setConfirm({
                          title: "Khôi phục ngân hàng gốc?",
                          text: "Ngân hàng chỉnh sửa trên thiết bị sẽ được thay bằng ngân hàng đi kèm website. Lịch sử vẫn được giữ.",
                          action: () =>
                            storage
                              .resetBank()
                              .then(() => {
                                setBank(INITIAL_BANK);
                                notify("Đã khôi phục ngân hàng gốc.");
                              })
                              .catch((e) => setError(String(e))),
                        })
                      }
                    >
                      Khôi phục ngân hàng gốc
                    </button>
                    <button
                      className="button danger"
                      onClick={() =>
                        setConfirm({
                          title: "Xóa toàn bộ lịch sử?",
                          text: "Tất cả bài đã hoàn thành sẽ bị xóa khỏi thiết bị. Hãy xuất sao lưu trước nếu muốn giữ lại.",
                          action: () => {
                            Promise.all(
                              history.map((a) => storage.deleteAttempt(a.id)),
                            )
                              .then(() => {
                                setAttempts((prev) =>
                                  prev.filter((a) => a.status === "active"),
                                );
                                notify("Đã xóa lịch sử.");
                              })
                              .catch((e) => setError(String(e)));
                          },
                        })
                      }
                    >
                      Xóa lịch sử
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        <footer className="footer">
          <span>Sản khoa Y4</span>
          <span>
            Tài liệu học là nguồn chính · Guideline được đối chiếu trong lời
            giải
          </span>
          <span>
            <ShieldCheck size={13} />
            Bài làm lưu cục bộ
          </span>
        </footer>
      </main>
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={19} />
          {toast}
        </div>
      )}
      {confirm && (
        <Modal title={confirm.title} onClose={() => setConfirm(null)}>
          <p>{confirm.text}</p>
          <div className="modal-actions">
            <button
              className="button secondary"
              onClick={() => setConfirm(null)}
            >
              Quay lại
            </button>
            <button
              className="button primary"
              onClick={() => {
                const action = confirm.action;
                setConfirm(null);
                action();
              }}
            >
              Xác nhận
            </button>
          </div>
        </Modal>
      )}
      {editor !== undefined && (
        <QuestionEditor
          question={editor}
          onClose={() => setEditor(undefined)}
          onSave={async (q) => {
            try {
              if (editor === null && bank.some((x) => x.id === q.id))
                throw new Error("ID đã tồn tại. Chọn ID khác.");
              const next = editor
                ? bank.map((x) => (x.id === editor.id ? q : x))
                : [...bank, q];
              await persistBank(next);
              setEditor(undefined);
            } catch (e) {
              setError((e as Error).message);
            }
          }}
        />
      )}
      {inspect && (
        <Modal
          title={inspect.id + " · " + LEVELS[inspect.difficulty - 1]}
          onClose={() => setInspect(null)}
          wide
        >
          <QuestionContent question={inspect} onZoom={() => setZoom(inspect)} />
          <div className="review-options">
            {inspect.options.map((o, i) => (
              <div
                className={i === inspect.correctAnswer ? "correct" : ""}
                key={i}
              >
                <b>{String.fromCharCode(65 + i)}</b>
                <RichText text={o} />
                {i === inspect.correctAnswer && <Check size={17} />}
              </div>
            ))}
          </div>
          <Explanation question={inspect} />
        </Modal>
      )}
      {zoom?.image && (
        <Modal title="Hình ảnh học" onClose={() => setZoom(null)} wide>
          <img
            className="zoom-image"
            src={base + zoom.image.src}
            alt={zoom.image.alt}
          />
          <p className="small">
            {zoom.image.credit} · {zoom.image.license}
          </p>
        </Modal>
      )}
    </div>
  );
}

function PageIntro({
  label,
  title,
  text,
}: {
  label: string;
  title: string;
  text: string;
}) {
  return (
    <div className="page-intro">
      <span>{label}</span>
      <h1>{title}</h1>
      <p>{text}</p>
    </div>
  );
}
function Stat({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: typeof BookOpen;
}) {
  return (
    <div className="stat">
      <span>
        <Icon size={20} />
        {label}
      </span>
      <strong>{value}</strong>
    </div>
  );
}
function QuestionContent({
  question: q,
  onZoom,
}: {
  question: Question;
  onZoom: () => void;
}) {
  return (
    <>
      {q.clinicalCase && (
        <div className="clinical-case">
          <span>
            <Stethoscope size={16} />
            TÌNH HUỐNG LÂM SÀNG
          </span>
          <p>
            <RichText text={q.clinicalCase} />
          </p>
        </div>
      )}
      {q.image && (
        <button
          className="question-image"
          aria-label="Phóng to hình ảnh học"
          onClick={onZoom}
        >
          <img src={base + q.image.src} alt={q.image.alt} />
          <span>
            <Maximize2 size={15} />
            Phóng to ảnh
          </span>
        </button>
      )}
      <h2 className="question-text">
        <RichText text={q.question} />
      </h2>
    </>
  );
}
function Explanation({ question: q }: { question: Question }) {
  const source = SOURCES.find((s) => s.id === q.source.documentId);
  return (
    <div className="explanation">
      <h4>
        <BookOpen size={17} />
        Lời giải theo tài liệu học
      </h4>
      <p>
        <RichText text={q.explanation} />
      </p>
      <div className="reference">
        <FileText size={15} />
        <span>
          {source?.title || q.source.documentId} · {q.source.locator}
        </span>
      </div>
      {q.image && (
        <div className="image-credit">
          <p>{q.image.caption}</p>
          <a href={q.image.sourceUrl} target="_blank" rel="noreferrer">
            Nguồn ảnh
          </a>{" "}
          · {q.image.credit} · {q.image.license}
        </div>
      )}
      {q.updates?.map((u, i) => (
        <div className="guideline-update" key={i}>
          <h4>Cập nhật guideline · {u.year}</h4>
          <p>{u.note}</p>
          <a href={u.url} target="_blank" rel="noreferrer">
            {u.title}
            <ArrowRight size={13} />
          </a>
        </div>
      ))}
    </div>
  );
}
function ExamView({
  attempt: a,
  now,
  saveStatus,
  onAnswer,
  onMove,
  onFlag,
  onZoom,
  onSubmit,
}: {
  attempt: Attempt;
  now: number;
  saveStatus: string;
  onAnswer: (i: number) => void;
  onMove: (i: number) => void;
  onFlag: () => void;
  onZoom: (q: Question) => void;
  onSubmit: () => void;
}) {
  const [onlyBlank, setOnlyBlank] = useState(false);
  const q = a.questions[a.current],
    answered = Object.keys(a.answers).length,
    remaining = a.deadline === null ? null : a.deadline - now;
  return (
    <>
      <div className="exam-header">
        <div>
          <span className="eyebrow">
            {a.config.mode === "exam" ? "BÀI KIỂM TRA" : "LUYỆN TẬP TỰ DO"}
          </span>
          <h1>
            {a.config.name
              ? `${a.config.name} · Sản khoa`
              : "Sản khoa tổng hợp"}
          </h1>
          <p>
            {a.questions.length} câu ·{" "}
            {a.config.topics.length
              ? a.config.topics.map(topicTitle).join(", ")
              : "Toàn bộ chủ đề"}
          </p>
        </div>
        <div
          className={
            "timer " +
            (remaining !== null && remaining < 300000 ? "urgent" : "")
          }
        >
          <Clock size={21} />
          <div>
            <small>
              {remaining === null ? "Chế độ luyện tập" : "Thời gian còn lại"}
            </small>
            <strong>
              {remaining === null ? "Không giới hạn" : timeLabel(remaining)}
            </strong>
          </div>
        </div>
      </div>
      <div className="exam-progress">
        <div>
          <span>
            {answered}/{a.questions.length} câu đã trả lời
          </span>
          <span
            className={
              saveStatus === "Lưu chưa thành công" ? "danger-text" : "saved"
            }
          >
            <CheckCircle2 size={14} />
            {saveStatus}
          </span>
        </div>
        <div className="bar-track">
          <div style={{ width: (answered / a.questions.length) * 100 + "%" }} />
        </div>
      </div>
      <div className="exam-body">
        <section className="panel question-panel">
          <div className="question-topline">
            <Badge>
              Câu {a.current + 1}/{a.questions.length}
            </Badge>
            <Badge kind={"level-" + q.difficulty}>
              {LEVELS[q.difficulty - 1]}
            </Badge>
            <button
              className={
                "flag-button " + (a.flags.includes(q.id) ? "flagged" : "")
              }
              onClick={onFlag}
            >
              <Flag size={16} />
              {a.flags.includes(q.id) ? "Đã đánh dấu" : "Xem lại sau"}
            </button>
          </div>
          <span className="question-lesson">{q.lesson}</span>
          <QuestionContent question={q} onZoom={() => onZoom(q)} />
          <div
            className="answer-options"
            role="radiogroup"
            aria-label="Chọn đáp án"
          >
            {q.optionOrder.map((original, i) => (
              <button
                key={i}
                role="radio"
                aria-checked={a.answers[q.id] === i}
                className={a.answers[q.id] === i ? "selected" : ""}
                onClick={() => onAnswer(i)}
              >
                <span className="option-letter">
                  {String.fromCharCode(65 + i)}
                </span>
                <span>
                  <RichText text={q.options[original]} />
                </span>
                {a.answers[q.id] === i && <CheckCircle2 size={20} />}
              </button>
            ))}
          </div>
          <div className="question-navigation">
            <button
              className="button secondary"
              disabled={a.current === 0}
              onClick={() => onMove(a.current - 1)}
            >
              <ArrowLeft size={17} />
              Câu trước
            </button>
            <span className="muted">Chọn một đáp án đúng nhất</span>
            <button
              className="button primary"
              disabled={a.current === a.questions.length - 1}
              onClick={() => onMove(a.current + 1)}
            >
              Câu tiếp
              <ArrowRight size={17} />
            </button>
          </div>
        </section>
        <aside className="panel question-map">
          <h3>Danh sách câu hỏi</h3>
          <div className="map-legend">
            <span>
              <i className="done" />
              Đã trả lời
            </span>
            <span>
              <i className="flagged" />
              Cần xem lại
            </span>
          </div>
          <label className="check-field">
            <input
              type="checkbox"
              checked={onlyBlank}
              onChange={(e) => setOnlyBlank(e.target.checked)}
            />
            Chỉ câu chưa trả lời
          </label>
          <div className="question-numbers">
            {a.questions
              .map((item, i) => ({ item, i }))
              .filter(
                ({ item }) => !onlyBlank || a.answers[item.id] === undefined,
              )
              .map(({ item, i }) => (
                <button
                  key={item.id}
                  className={
                    (a.answers[item.id] !== undefined ? "done " : "") +
                    (a.current === i ? "current " : "") +
                    (a.flags.includes(item.id) ? "flagged" : "")
                  }
                  aria-label={`Câu ${i + 1}${a.answers[item.id] !== undefined ? ", đã trả lời" : ""}${a.flags.includes(item.id) ? ", cần xem lại" : ""}`}
                  onClick={() => onMove(i)}
                >
                  {i + 1}
                </button>
              ))}
          </div>
          <button className="button primary large" onClick={onSubmit}>
            Nộp bài
            <CheckCircle2 size={18} />
          </button>
          <p className="small muted">
            Bạn có thể thay đổi đáp án trước khi nộp.
          </p>
        </aside>
      </div>
    </>
  );
}
function ResultView({
  attempt: a,
  onZoom,
  onShare,
  onWrong,
  onRetry,
  onNew,
}: {
  attempt: Attempt;
  onZoom: (q: Question) => void;
  onShare?: () => void;
  onWrong: () => void;
  onRetry: () => void;
  onNew: () => void;
}) {
  const [filter, setFilter] = useState("all"),
    [expanded, setExpanded] = useState<string[]>([]);
  const r = grade(a);
  const review = a.questions
    .map((q, i) => ({ q, i }))
    .filter(
      ({ q }) =>
        filter === "all" ||
        (filter === "wrong"
          ? a.answers[q.id] !== undefined &&
            q.optionOrder[a.answers[q.id]] !== q.correctAnswer
          : a.answers[q.id] === undefined),
    );
  return (
    <>
      <PageIntro
        label="KẾT QUẢ BÀI KIỂM TRA"
        title="Một lượt ôn đã hoàn thành"
        text={`${a.config.name || "Bạn"} · ${date(a.completedAt!)}${a.completionReason === "expired" ? " · Tự động hoàn tất khi hết giờ" : ""}`}
      />
      <div className="result-hero">
        <div
          className="result-ring"
          style={{
            background: `conic-gradient(var(--teal) ${(r.correct / r.total) * 360}deg,var(--line) 0)`,
          }}
        >
          <div>
            <strong>
              {r.correct}
              <span>/{r.total}</span>
            </strong>
            <small>câu đúng</small>
          </div>
        </div>
        <div className="result-summary">
          <h2>Kết quả theo số câu</h2>
          <p>Đối chiếu lời giải để hiểu phần cần ôn thêm.</p>
          <div className="result-counts">
            <span>
              <i className="dot success" />
              <b>{r.correct}</b>Đúng
            </span>
            <span>
              <i className="dot danger" />
              <b>{r.wrong}</b>Sai
            </span>
            <span>
              <i className="dot blank" />
              <b>{r.blank}</b>Bỏ trống
            </span>
            <span>
              <Clock size={16} />
              <b>{timeLabel(a.completedAt! - a.startedAt)}</b>Thời gian
            </span>
          </div>
        </div>
        <div className="result-actions">
          <button
            className="button primary"
            disabled={!r.wrong}
            onClick={onWrong}
          >
            <RefreshCw size={17} />
            Ôn những câu đã sai
          </button>
          <button className="button secondary" onClick={onNew}>
            <Plus size={16} />
            Tạo đề cùng phạm vi
          </button>
          <div>
            <button className="text-button" onClick={onRetry}>
              Làm lại đề
            </button>
            {onShare && (
              <button className="text-button" onClick={onShare}>
                <Share2 size={15} />
                Chia sẻ đề
              </button>
            )}
          </div>
        </div>
      </div>
      <div className="analysis-grid">
        <div className="panel">
          <h3>Theo mức độ khó</h3>
          <Bars
            groups={breakdown(a, "difficulty")}
            label={(k) => LEVELS[Number(k) - 1]}
          />
        </div>
        <div className="panel">
          <h3>Theo chủ đề</h3>
          <Bars groups={breakdown(a, "topic")} label={topicTitle} />
        </div>
      </div>
      <div className="section-heading">
        <div>
          <h2>Đáp án & lời giải</h2>
          <p>Xem lại bệnh cảnh, đáp án đã chọn và căn cứ trong tài liệu.</p>
        </div>
        <select
          aria-label="Lọc câu trong kết quả"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="all">Tất cả câu</option>
          <option value="wrong">Câu trả lời sai</option>
          <option value="blank">Câu bỏ trống</option>
        </select>
      </div>
      <div className="review-list">
        {review.map(({ q, i }) => {
          const chosen = a.answers[q.id],
            isRight = q.optionOrder[chosen] === q.correctAnswer,
            open = expanded.includes(q.id);
          return (
            <article className="review-card" key={q.id}>
              <button
                className="review-heading"
                onClick={() =>
                  setExpanded(
                    open
                      ? expanded.filter((x) => x !== q.id)
                      : [...expanded, q.id],
                  )
                }
              >
                <span
                  className={
                    "review-state " +
                    (chosen === undefined
                      ? "blank"
                      : isRight
                        ? "correct"
                        : "wrong")
                  }
                >
                  {chosen === undefined ? (
                    <MoreHorizontal size={18} />
                  ) : isRight ? (
                    <Check size={18} />
                  ) : (
                    <X size={18} />
                  )}
                </span>
                <div>
                  <span>
                    Câu {i + 1} · {LEVELS[q.difficulty - 1]}
                  </span>
                  <strong>{q.question}</strong>
                </div>
                <ChevronRight size={20} className={open ? "rotate" : ""} />
              </button>
              {open && (
                <div className="review-details">
                  <QuestionContent question={q} onZoom={() => onZoom(q)} />
                  <div className="review-options">
                    {q.optionOrder.map((idx, j) => (
                      <div
                        key={j}
                        className={
                          (idx === q.correctAnswer ? "correct " : "") +
                          (chosen === j && idx !== q.correctAnswer
                            ? "wrong"
                            : "")
                        }
                      >
                        <b>{String.fromCharCode(65 + j)}</b>
                        <RichText text={q.options[idx]} />
                        {idx === q.correctAnswer && (
                          <Badge kind="mint">Đáp án đúng</Badge>
                        )}
                        {chosen === j && <Badge>Bạn chọn</Badge>}
                      </div>
                    ))}
                  </div>
                  <Explanation question={q} />
                </div>
              )}
            </article>
          );
        })}
      </div>
      {!review.length && (
        <Empty title="Không có câu trong bộ lọc">
          Chọn bộ lọc khác để xem đáp án.
        </Empty>
      )}
    </>
  );
}
function Bars({
  groups,
  label,
}: {
  groups: Record<string, { correct: number; total: number }>;
  label: (key: string) => string;
}) {
  return (
    <div className="analysis-bars">
      {Object.entries(groups).map(([k, g]) => (
        <div key={k}>
          <div>
            <span>{label(k)}</span>
            <b>
              {g.correct}/{g.total} đúng
            </b>
          </div>
          <div className="bar-track">
            <div style={{ width: (g.correct / g.total) * 100 + "%" }} />
          </div>
        </div>
      ))}
    </div>
  );
}
function AggregateBars({
  history,
  type,
}: {
  history: Attempt[];
  type: "difficulty" | "topic";
}) {
  const groups: Record<string, { correct: number; total: number }> =
    Object.create(null);
  history.forEach((a) =>
    Object.entries(breakdown(a, type)).forEach(([k, g]) => {
      groups[k] ??= { correct: 0, total: 0 };
      groups[k].correct += g.correct;
      groups[k].total += g.total;
    }),
  );
  return (
    <Bars
      groups={groups}
      label={type === "topic" ? topicTitle : (k) => LEVELS[Number(k) - 1]}
    />
  );
}
function QuestionEditor({
  question: q,
  onSave,
  onClose,
}: {
  question: Question | null;
  onSave: (q: Question) => void;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState<Question>(
    q
      ? structuredClone(q)
      : {
          id: "LOCAL-" + crypto.randomUUID().slice(0, 8),
          subject: "Sản khoa",
          grade: 4,
          chapter: TOPICS[0].title,
          lesson: "",
          topic: TOPICS[0].id,
          difficulty: 3,
          type: "multiple_choice",
          question: "",
          clinicalCase: "",
          options: ["", "", "", ""],
          correctAnswer: 0,
          explanation: "",
          source: { documentId: "", locator: "" },
        },
  );
  function field(key: keyof Question, value: unknown) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }
  return (
    <Modal title={q ? "Sửa câu hỏi" : "Thêm câu hỏi"} onClose={onClose} wide>
      <form
        className="editor"
        onSubmit={(e) => {
          e.preventDefault();
          const clean = { ...draft };
          if (!clean.clinicalCase) delete clean.clinicalCase;
          onSave(clean);
        }}
      >
        <div className="field-grid">
          <label className="field">
            ID duy nhất
            <input
              required
              value={draft.id}
              maxLength={100}
              onChange={(e) => field("id", e.target.value)}
            />
          </label>
          <label className="field">
            Mức độ
            <select
              value={draft.difficulty}
              onChange={(e) => field("difficulty", Number(e.target.value))}
            >
              {LEVELS.map((l, i) => (
                <option key={l} value={i + 1}>
                  {l}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div className="field-grid">
          <label className="field">
            Chủ đề
            <select
              value={draft.topic}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  topic: e.target.value,
                  chapter: topicTitle(e.target.value),
                })
              }
            >
              {TOPICS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Bài học
            <input
              required
              value={draft.lesson}
              onChange={(e) => field("lesson", e.target.value)}
            />
          </label>
        </div>
        <div className="field-grid">
          <label className="field">
            Môn học
            <input
              required
              value={draft.subject}
              onChange={(e) => field("subject", e.target.value)}
            />
          </label>
          <label className="field">
            Năm học
            <input
              required
              type="number"
              min={1}
              max={20}
              value={draft.grade}
              onChange={(e) => field("grade", Number(e.target.value))}
            />
          </label>
        </div>
        <label className="field">
          Chương
          <input
            required
            value={draft.chapter}
            onChange={(e) => field("chapter", e.target.value)}
          />
        </label>
        <label className="field">
          Tình huống lâm sàng
          <textarea
            value={draft.clinicalCase || ""}
            onChange={(e) => field("clinicalCase", e.target.value)}
            placeholder="Cung cấp đủ dữ kiện cho câu hỏi. Ghi rõ nếu là tình huống luyện tập giả định."
          />
        </label>
        <label className="field">
          Nội dung câu hỏi
          <textarea
            required
            value={draft.question}
            onChange={(e) => field("question", e.target.value)}
          />
        </label>
        {draft.options.map((o, i) => (
          <label className="field option-editor" key={i}>
            <input
              aria-label={"Chọn đáp án đúng " + String.fromCharCode(65 + i)}
              type="radio"
              checked={draft.correctAnswer === i}
              onChange={() => field("correctAnswer", i)}
            />
            <span>{String.fromCharCode(65 + i)}</span>
            <input
              required
              aria-label={"Nội dung phương án " + String.fromCharCode(65 + i)}
              value={o}
              onChange={(e) =>
                field(
                  "options",
                  draft.options.map((x, j) => (j === i ? e.target.value : x)),
                )
              }
            />
          </label>
        ))}
        <label className="field">
          Lời giải
          <textarea
            required
            value={draft.explanation}
            onChange={(e) => field("explanation", e.target.value)}
          />
        </label>
        <div className="field-grid">
          <label className="field">
            Tài liệu nguồn
            <select
              required
              value={draft.source.documentId}
              onChange={(e) =>
                field("source", { ...draft.source, documentId: e.target.value })
              }
            >
              <option value="">Chọn tài liệu</option>
              {SOURCES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Trang / slide / mục
            <input
              required
              value={draft.source.locator}
              onChange={(e) =>
                field("source", { ...draft.source, locator: e.target.value })
              }
            />
          </label>
        </div>
        {draft.image && (
          <p className="small muted">
            Câu này có ảnh và thông tin nguồn ảnh. Dữ liệu ảnh được giữ khi sửa;
            ảnh mới được bổ sung qua ngân hàng JSON và tệp ảnh trong dự án.
          </p>
        )}
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Hủy
          </button>
          <button type="submit" className="button primary">
            <Check size={17} />
            Lưu câu hỏi
          </button>
        </div>
      </form>
    </Modal>
  );
}
