import { test, expect, type Page } from "@playwright/test";
async function open(page: Page) {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Vững kiến thức. Tự tin trước mỗi ca." }),
  ).toBeVisible();
}
async function configure(page: Page, count = "4", practice = true) {
  await page
    .getByRole("button", { name: "Tạo đề kiểm tra", exact: true })
    .last()
    .click();
  await page.getByLabel("Số câu trắc nghiệm", { exact: true }).fill(count);
  if (practice)
    await page
      .getByRole("button", { name: "Luyện tập tự do Không giới hạn thời gian" })
      .click();
}
async function begin(page: Page) {
  await page
    .getByRole("button", { name: "Bắt đầu làm bài", exact: true })
    .click();
  await expect(
    page.getByRole("radiogroup", { name: "Chọn đáp án" }),
  ).toBeVisible();
  await expect(
    page.getByText("Đã lưu trên thiết bị", { exact: true }),
  ).toBeVisible();
}
async function submit(page: Page) {
  await page.getByRole("button", { name: "Nộp bài", exact: true }).click();
  await page.getByRole("button", { name: "Xác nhận", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Một lượt ôn đã hoàn thành" }),
  ).toBeVisible();
}

test("ngân hàng900, mặc định90/90 vàquota9/13/36/32", async ({ page }) => {
  await open(page);
  await expect(
    page.getByRole("button", { name: "Ngân hàng câu hỏi 900" }),
  ).toBeVisible();
  await page.screenshot({ path: "reports/preview-desktop.png" });
  await configure(page, "90", false);
  await expect(
    page.getByLabel("Thời gian (phút)", { exact: true }),
  ).toHaveValue("90");
  for (const n of [9, 13, 36, 32])
    await expect(
      page.locator(".quota-list").getByText(`${n} câu`, { exact: true }),
    ).toBeVisible();
  await begin(page);
  await expect(page.locator(".question-numbers button")).toHaveCount(90);
});
test("snapshot, đáp án, flags vàcursor giữ sau tải lại; nộp và ôn câu sai", async ({
  page,
}) => {
  await open(page);
  await configure(page);
  await begin(page);
  const firstText = await page.locator(".question-text").innerText();
  const options = await page.getByRole("radio").allTextContents();
  await page.getByRole("radio").first().click();
  await page.getByRole("button", { name: "Xem lại sau", exact: true }).click();
  await page.getByRole("button", { name: "Câu tiếp", exact: true }).click();
  const secondText = await page.locator(".question-text").innerText();
  await expect(
    page.getByText("Đã lưu trên thiết bị", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.locator(".question-text")).toHaveText(secondText);
  await expect(
    page.getByRole("button", {
      name: "Câu 1, đã trả lời, cần xem lại",
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Câu trước", exact: true }).click();
  await expect(page.locator(".question-text")).toHaveText(firstText);
  expect(await page.getByRole("radio").allTextContents()).toEqual(options);
  await expect(page.getByRole("radio").first()).toHaveAttribute(
    "aria-checked",
    "true",
  );
  await submit(page);
  await expect(
    page.getByText("3", { exact: true }).filter({ visible: true }).first(),
  ).toBeVisible();
  await page.locator(".review-heading").first().click();
  await expect(
    page.getByRole("heading", { name: "Lời giải theo tài liệu học" }),
  ).toBeVisible();
  await expect(page.locator(".reference")).toBeVisible();
  const wrong = await page
    .getByRole("button", { name: "Ôn những câu đã sai", exact: true })
    .isEnabled();
  if (wrong) {
    await page
      .getByRole("button", { name: "Ôn những câu đã sai", exact: true })
      .click();
    await expect(page.locator(".question-numbers button")).toHaveCount(1);
    await expect(
      page.getByText("Không giới hạn", { exact: true }),
    ).toBeVisible();
  }
});
test("đồng hồ tiếp tục sau tải lại và tự hoàn tất khi mở lại quá hạn", async ({
  page,
  context,
}) => {
  const start = new Date("2026-10-11T05:00:00Z");
  await page.clock.install({ time: start });
  await open(page);
  await configure(page, "1", false);
  await page.getByLabel("Thời gian (phút)", { exact: true }).fill("1");
  await begin(page);
  await page.clock.fastForward(10000);
  await page.reload();
  await expect(page.locator(".timer strong")).toHaveText(/00:00:(49|50)/);
  await page.close();
  const reopened = await context.newPage();
  await reopened.clock.install({ time: new Date(start.getTime() + 70000) });
  await reopened.goto("/#exam");
  await expect(
    reopened.getByRole("heading", { name: "Một lượt ôn đã hoàn thành" }),
  ).toBeVisible();
  await expect(
    reopened.getByText(/Tự động hoàn tất khi hết giờ/),
  ).toBeVisible();
  await expect(reopened.locator(".result-counts")).toContainText("00:01:00");
  await expect(reopened.getByRole("radio")).toHaveCount(0);
});
test("ngoại tuyến vẫn mở, tạo đề vàlưu; không gọi dịchvụ bênngoài", async ({
  page,
  context,
}) => {
  const external: string[] = [];
  page.on("request", (r) => {
    const u = new URL(r.url());
    if (
      u.protocol.startsWith("http") &&
      !["127.0.0.1", "localhost"].includes(u.hostname)
    )
      external.push(u.href);
  });
  await open(page);
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
  });
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Vững kiến thức. Tự tin trước mỗi ca." }),
  ).toBeVisible();
  await context.setOffline(true);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Vững kiến thức. Tự tin trước mỗi ca." }),
  ).toBeVisible();
  await configure(page);
  await begin(page);
  await page.getByRole("radio").first().click();
  await expect(
    page.getByText("Đã lưu trên thiết bị", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByRole("radio").first()).toHaveAttribute(
    "aria-checked",
    "true",
  );
  expect(external).toEqual([]);
});
test("mobile390px, menu, tìmkiếm, darkmode và câu ảnh cócase", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await open(page);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(
    390,
  );
  await page.getByRole("button", { name: "Chuyển sang chế độ tối" }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.screenshot({ path: "reports/preview-mobile.png" });
  await page.getByRole("button", { name: "Mở menu" }).click();
  await page.getByRole("button", { name: "Ngân hàng câu hỏi 900" }).click();
  await page.locator(".global-search svg").click();
  await page.getByRole("textbox", { name: "Tìm kiếm" }).fill("I004");
  await expect(page.locator(".bank-row")).toHaveCount(1);
  await page.locator(".bank-question").click();
  await expect(page.locator(".clinical-case")).toContainText(
    "Tình huống luyện tập:",
  );
  await expect(page.locator(".question-image img")).toBeVisible();
  expect(
    await page
      .locator(".question-image img")
      .evaluate((im: HTMLImageElement) => im.naturalWidth),
  ).toBeGreaterThan(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(
    390,
  );
});
test("xuất nhập JSON vàCSV ngân hàng, lịch sử hoàn thành", async ({ page }) => {
  await open(page);
  await configure(page, "1");
  await begin(page);
  await submit(page);
  await page
    .getByRole("button", { name: "Lịch sử làm bài", exact: true })
    .click();
  const dl = page.waitForEvent("download");
  await page.getByRole("button", { name: "Xuất JSON", exact: true }).click();
  const file = await (await dl).path();
  expect(file).toBeTruthy();
  await page.locator("input[type=file]").setInputFiles(file!);
  await expect(page.getByRole("status")).toContainText(
    "Đã nhập 0 bài làm. Giữ nguyên 1 bài đã có trên thiết bị.",
  );
  await page.getByRole("button", { name: "Ngân hàng câu hỏi 900" }).click();
  for (const format of ["JSON", "CSV"]) {
    const promise = page.waitForEvent("download");
    await page.getByRole("button", { name: format, exact: true }).click();
    const download = await promise;
    const path = ".local-qa/test-bank." + format.toLowerCase();
    await download.saveAs(path);
    await page.locator("input[type=file]").setInputFiles(path);
    await expect(
      page.getByRole("dialog", { name: "Nhập ngân hàng câu hỏi" }),
    ).toContainText("Tệp có 900 câu");
    await page.getByRole("button", { name: "Xác nhận", exact: true }).click();
    await expect(page.getByRole("status")).toContainText("Đã lưu ngân hàng");
  }
});
test("nhấn bắt đầu liên tiếp chỉ tạo một bài đang làm", async ({ page }) => {
  await open(page);
  await configure(page, "1");
  await page
    .getByRole("button", { name: "Bắt đầu làm bài", exact: true })
    .evaluate((button: HTMLButtonElement) => {
      button.click();
      button.click();
    });
  await expect(
    page.getByRole("radiogroup", { name: "Chọn đáp án" }),
  ).toBeVisible();
  const count = await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve) => {
      const request = indexedDB.open("san-khoa-y4", 1);
      request.onsuccess = () => resolve(request.result);
    });
    const attempts = await new Promise<Array<{ status: string }>>((resolve) => {
      const request = db
        .transaction("attempts")
        .objectStore("attempts")
        .getAll();
      request.onsuccess = () => resolve(request.result);
    });
    db.close();
    return attempts.filter((a) => a.status === "active").length;
  });
  expect(count).toBe(1);
});
test("lỗi lưu có cảnh báo đóng trang kể cả khi đã nộp bài", async ({
  page,
}) => {
  await open(page);
  await configure(page, "1");
  await begin(page);
  await page.evaluate(() => {
    IDBObjectStore.prototype.put = function () {
      throw new DOMException("Test quota", "QuotaExceededError");
    };
  });
  await page.getByRole("radio").first().click();
  await expect(page.getByText(/Không lưu được bài làm/)).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        !window.dispatchEvent(new Event("beforeunload", { cancelable: true })),
    ),
  ).toBe(true);
  await submit(page);
  expect(
    await page.evaluate(
      () =>
        !window.dispatchEvent(new Event("beforeunload", { cancelable: true })),
    ),
  ).toBe(true);
});
test("khôi phục bản dự phòng trên thiết bị mới; không mở lại bài đã nộp", async ({
  page,
  browser,
}) => {
  await open(page);
  await configure(page, "1");
  await begin(page);
  await page.getByRole("radio").first().click();
  await expect(
    page.getByText("Đã lưu trên thiết bị", { exact: true }),
  ).toBeVisible();
  const prompt = await page.locator(".question-text").innerText();
  await page
    .getByRole("button", { name: "Cài đặt & sao lưu", exact: true })
    .click();
  const downloadPromise = page.waitForEvent("download");
  await page
    .getByRole("button", {
      name: "Xuất bản dự phòng bài đang làm",
      exact: true,
    })
    .click();
  const path = await (await downloadPromise).path();
  expect(path).toBeTruthy();
  const fresh = await browser.newContext();
  const restored = await fresh.newPage();
  await restored.goto(page.url());
  await restored
    .getByLabel("Khôi phục bài từ bản dự phòng")
    .setInputFiles(path!);
  await expect(restored.locator(".question-text")).toHaveText(prompt);
  await expect(restored.getByRole("radio").first()).toHaveAttribute(
    "aria-checked",
    "true",
  );
  await expect(
    restored.getByText("Không giới hạn", { exact: true }),
  ).toBeVisible();
  await fresh.close();
  await page.goto("/#exam");
  await submit(page);
  await page
    .getByRole("button", { name: "Cài đặt & sao lưu", exact: true })
    .click();
  await page.getByLabel("Khôi phục bài từ bản dự phòng").setInputFiles(path!);
  await expect(
    page.getByText(/Bản dự phòng không thể ghi đè hoặc mở lại bài đã nộp/),
  ).toBeVisible();
});
