import type { Attempt, ExamConfig, ExamQuestion, Question } from "../types";
export const ALGORITHM_VERSION = "1";
export function hash(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
const byId = (a: Question, b: Question) =>
  a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
export function fingerprint(bank: Question[]): string {
  return (
    "y4-" +
    hash(JSON.stringify([...bank].sort(byId).map(canonicalQuestion))).toString(
      16,
    )
  );
}
function canonicalQuestion(q: Question) {
  return [
    q.id,
    q.subject,
    q.grade,
    q.chapter,
    q.lesson,
    q.topic,
    q.difficulty,
    q.type,
    q.question,
    q.clinicalCase || "",
    q.options,
    q.correctAnswer,
    q.explanation,
    [q.source.documentId, q.source.locator],
    (q.updates || []).map((u) => [u.title, u.url, u.year, u.note]),
    q.image
      ? [
          q.image.src,
          q.image.alt,
          q.image.caption,
          q.image.sourceUrl,
          q.image.credit,
          q.image.license,
        ]
      : null,
  ];
}
export function random(seed: string) {
  let state = hash(seed);
  return () => {
    state += 0x6d2b79f5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function shuffle<T>(values: T[], rng: () => number): T[] {
  const a = [...values];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
export function quotas(count: number, ratios: number[]): number[] {
  if (!Number.isInteger(count) || count < 1 || count > 2000)
    throw new Error("Số câu phải là số nguyên từ 1 đến 2.000.");
  if (
    ratios.length !== 4 ||
    ratios.some((x) => !Number.isFinite(x) || x < 0 || x > 100) ||
    Math.abs(ratios.reduce((a, b) => a + b, 0) - 100) > 1e-7
  )
    throw new Error("Tổng tỉ lệ 4 mức độ phải bằng 100%.");
  const exact = ratios.map((x) => (x * count) / 100),
    result = exact.map(Math.floor);
  const order = [0, 1, 2, 3].sort(
    (a, b) => exact[b] - result[b] - (exact[a] - result[a]) || b - a,
  );
  const remaining = count - result.reduce((a, b) => a + b, 0);
  for (let i = 0; i < remaining; i++) result[order[i]]++;
  return result;
}
export function filterBank(bank: Question[], config: ExamConfig): Question[] {
  return bank.filter(
    (q) =>
      (!config.subject || q.subject === config.subject) &&
      (!config.grade || q.grade === config.grade) &&
      (!config.chapters?.length || config.chapters.includes(q.chapter)) &&
      (!config.topics.length || config.topics.includes(q.topic)) &&
      (!config.lessons.length || config.lessons.includes(q.lesson)) &&
      (config.images === "all" ||
        (config.images === "with" ? !!q.image : !q.image)),
  );
}
export function availability(bank: Question[], config: ExamConfig) {
  const pool = filterBank(bank, config);
  return [1, 2, 3, 4].map(
    (level) => pool.filter((q) => q.difficulty === level).length,
  );
}
export function selectQuestions(
  bank: Question[],
  config: ExamConfig,
  seed: string,
): ExamQuestion[] {
  const need = quotas(config.count, config.ratios),
    pool = filterBank(bank, config),
    rng = random(seed),
    selected: Question[] = [];
  need.forEach((n, i) => {
    const group = pool.filter((q) => q.difficulty === i + 1).sort(byId);
    if (group.length < n)
      throw new Error(
        `Ngân hàng câu hỏi hiện chưa đủ số lượng theo yêu cầu của bạn. Mức ${i + 1}: cần ${n}, có ${group.length}. Hãy giảm số câu, thay đổi tỉ lệ hoặc chọn thêm chủ đề.`,
      );
    selected.push(...shuffle(group, rng).slice(0, n));
  });
  return shuffle(selected, rng).map((q) => ({
    ...structuredClone(q),
    optionOrder: shuffle([0, 1, 2, 3], rng),
  }));
}
export function newSeed(): string {
  const bytes = new Uint32Array(2);
  crypto.getRandomValues(bytes);
  return [...bytes].map((x) => x.toString(36)).join("-");
}
export function chooseSeed(
  bank: Question[],
  config: ExamConfig,
  history: Attempt[],
): string {
  const recent = history
    .slice()
    .sort((a, b) => b.startedAt - a.startedAt)
    .slice(0, 5);
  let best = "",
    penalty = Infinity;
  for (let i = 0; i < 20; i++) {
    const seed = newSeed(),
      selected = selectQuestions(bank, config, seed);
    const p = selected.reduce(
      (s, q) =>
        s +
        recent.reduce(
          (t, a, j) => t + (a.questions.some((x) => x.id === q.id) ? 6 - j : 0),
          0,
        ),
      0,
    );
    if (p < penalty) {
      penalty = p;
      best = seed;
    }
    if (!p) break;
  }
  return best;
}
export function createAttempt(
  bank: Question[],
  config: ExamConfig,
  history: Attempt[],
  seed?: string,
  now = Date.now(),
): Attempt {
  if (
    !Number.isFinite(config.minutes) ||
    config.minutes < 1 ||
    config.minutes > 1440
  )
    throw new Error("Thời gian phải từ 1 đến 1.440 phút.");
  const chosen = seed || chooseSeed(bank, config, history);
  return {
    id: crypto.randomUUID(),
    bankVersion: fingerprint(bank),
    algorithmVersion: ALGORITHM_VERSION,
    seed: chosen,
    config: structuredClone(config),
    questions: selectQuestions(bank, config, chosen),
    answers: {},
    flags: [],
    current: 0,
    startedAt: now,
    deadline: config.mode === "exam" ? now + config.minutes * 60000 : null,
    completedAt: null,
    status: "active",
  };
}
export function expired(a: Attempt, now = Date.now()) {
  return a.status === "active" && a.deadline !== null && now >= a.deadline;
}
export function finish(
  a: Attempt,
  reason: "manual" | "expired",
  now = Date.now(),
): Attempt {
  if (a.status === "completed") return a;
  return {
    ...a,
    status: "completed",
    completedAt: reason === "expired" && a.deadline !== null ? a.deadline : now,
    completionReason: reason,
  };
}
export function grade(a: Attempt) {
  let correct = 0,
    wrong = 0,
    blank = 0;
  const wrongIds: string[] = [];
  a.questions.forEach((q) => {
    const answer = a.answers[q.id];
    if (answer === undefined) blank++;
    else if (q.optionOrder[answer] === q.correctAnswer) correct++;
    else {
      wrong++;
      wrongIds.push(q.id);
    }
  });
  return { correct, wrong, blank, total: a.questions.length, wrongIds };
}
export function breakdown(a: Attempt, key: "difficulty" | "topic") {
  const groups: Record<string, { correct: number; total: number }> =
    Object.create(null);
  a.questions.forEach((q) => {
    const k = String(q[key]);
    groups[k] ??= { correct: 0, total: 0 };
    groups[k].total++;
    if (q.optionOrder[a.answers[q.id]] === q.correctAnswer) groups[k].correct++;
  });
  return groups;
}
export function wrongPractice(a: Attempt, now = Date.now()): Attempt {
  const ids = grade(a).wrongIds;
  if (!ids.length)
    throw new Error("Bài này chưa có câu trả lời sai để luyện lại.");
  const questions = a.questions
    .filter((q) => ids.includes(q.id))
    .map((q) => structuredClone(q));
  return {
    ...structuredClone(a),
    id: crypto.randomUUID(),
    seed: newSeed(),
    config: { ...a.config, count: questions.length, mode: "practice" },
    questions,
    answers: {},
    flags: [],
    current: 0,
    startedAt: now,
    deadline: null,
    completedAt: null,
    status: "active",
    completionReason: undefined,
  };
}
export function retryAttempt(a: Attempt, now = Date.now()): Attempt {
  return {
    ...structuredClone(a),
    id: crypto.randomUUID(),
    answers: {},
    flags: [],
    current: 0,
    startedAt: now,
    deadline: a.config.mode === "exam" ? now + a.config.minutes * 60000 : null,
    completedAt: null,
    status: "active",
    completionReason: undefined,
  };
}
export interface SharedExam {
  v: 1;
  b: string;
  a: string;
  s: string;
  c: Omit<ExamConfig, "name">;
}
export function sharePayload(a: Attempt): string {
  const { name, ...c } = a.config;
  return btoa(
    unescape(
      encodeURIComponent(
        JSON.stringify({
          v: 1,
          b: a.bankVersion,
          a: a.algorithmVersion,
          s: a.seed,
          c,
        }),
      ),
    ),
  );
}
export function canShare(a: Attempt, bank: Question[]): boolean {
  if (
    a.algorithmVersion !== ALGORITHM_VERSION ||
    a.bankVersion !== fingerprint(bank)
  )
    return false;
  try {
    return (
      JSON.stringify(
        selectQuestions(bank, a.config, a.seed).map((q) => [
          canonicalQuestion(q),
          q.optionOrder,
        ]),
      ) ===
      JSON.stringify(
        a.questions.map((q) => [canonicalQuestion(q), q.optionOrder]),
      )
    );
  } catch {
    return false;
  }
}
export function decodeShare(
  value: string,
  bank: Question[],
): { config: ExamConfig; seed: string } {
  if (value.length > 12000) throw new Error("Liên kết đề quá dài.");
  let data: SharedExam;
  try {
    data = JSON.parse(decodeURIComponent(escape(atob(value))));
  } catch {
    throw new Error("Liên kết đề không hợp lệ.");
  }
  if (
    data.v !== 1 ||
    data.a !== ALGORITHM_VERSION ||
    data.b !== fingerprint(bank)
  )
    throw new Error(
      "Phiên bản ngân hàng hoặc thuật toán không khớp. Không thể tái tạo chính xác đề được chia sẻ.",
    );
  const c = data.c;
  if (
    !c ||
    typeof data.s !== "string" ||
    data.s.length > 100 ||
    !["exam", "practice"].includes(c.mode) ||
    !["all", "with", "without"].includes(c.images) ||
    !Array.isArray(c.topics) ||
    !c.topics.every((x) => typeof x === "string") ||
    !Array.isArray(c.lessons) ||
    !c.lessons.every((x) => typeof x === "string") ||
    !Array.isArray(c.ratios)
  )
    throw new Error("Cấu hình trong liên kết không hợp lệ.");
  if (
    (c.subject !== undefined && typeof c.subject !== "string") ||
    (c.grade !== undefined && (!Number.isInteger(c.grade) || c.grade < 1)) ||
    (c.chapters !== undefined &&
      (!Array.isArray(c.chapters) ||
        !c.chapters.every((x) => typeof x === "string")))
  )
    throw new Error("Môn học, năm học hoặc chương không hợp lệ.");
  quotas(c.count, c.ratios);
  if (!Number.isFinite(c.minutes) || c.minutes < 1 || c.minutes > 1440)
    throw new Error("Thời gian trong liên kết không hợp lệ.");
  const config = { ...c, name: "" };
  selectQuestions(bank, config, data.s);
  return { config, seed: data.s };
}
