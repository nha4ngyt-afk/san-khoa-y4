import { openDB, type IDBPDatabase } from "idb";
import type { Attempt, Question } from "../types";
let database: Promise<IDBPDatabase> | undefined;
export function db() {
  return (database ??= openDB("san-khoa-y4", 1, {
    upgrade(d) {
      d.createObjectStore("attempts", { keyPath: "id" });
      d.createObjectStore("settings");
      d.createObjectStore("bank", { keyPath: "id" });
    },
  }));
}
export async function readState() {
  const d = await db();
  return {
    attempts: (await d.getAll("attempts")) as Attempt[],
    customBank: (await d.get("settings", "customBank")) as
      Question[] | undefined,
    theme: (await d.get("settings", "theme")) as string | undefined,
  };
}
export async function saveAttempt(a: Attempt) {
  const d = await db();
  await d.put("attempts", structuredClone(a));
}
export async function restoreAttempt(a: Attempt) {
  const d = await db();
  try {
    await d.add("attempts", structuredClone(a));
  } catch (e) {
    if ((e as DOMException).name === "ConstraintError")
      throw new Error(
        "Bài này đã có trên thiết bị. Bản dự phòng không thể ghi đè hoặc mở lại bài đã nộp.",
      );
    throw e;
  }
}
export async function deleteAttempt(id: string) {
  const d = await db();
  await d.delete("attempts", id);
}
export async function saveBank(bank: Question[]) {
  const d = await db();
  await d.put("settings", structuredClone(bank), "customBank");
}
export async function resetBank() {
  const d = await db();
  await d.delete("settings", "customBank");
}
export async function setTheme(theme: string) {
  const d = await db();
  await d.put("settings", theme, "theme");
}
export async function clearHistory() {
  const d = await db();
  await d.clear("attempts");
}
export async function importAttempts(attempts: Attempt[]) {
  const d = await db();
  const tx = d.transaction("attempts", "readwrite");
  let imported = 0;
  for (const a of attempts) {
    if (await tx.store.get(a.id)) continue;
    await tx.store.add(structuredClone(a));
    imported++;
  }
  await tx.done;
  return { imported, skipped: attempts.length - imported };
}
