import type { Attempt, Question } from "../types";
const text = (v: unknown, max = 20000) =>
  typeof v === "string" && v.trim().length > 0 && v.length <= max;
const safeUrl = (v: unknown) => typeof v === "string" && /^https:\/\//.test(v);
export function validateQuestions(data: unknown): {
  questions: Question[];
  warnings: string[];
} {
  if (!Array.isArray(data) || data.length < 1 || data.length > 10000)
    throw new Error("Ngân hàng cần có từ 1 đến 10.000 câu hỏi.");
  const ids = new Set<string>(),
    content = new Set<string>(),
    warnings: string[] = [];
  for (const [i, q] of data.entries()) {
    if (
      !q ||
      typeof q !== "object" ||
      !text(q.id, 100) ||
      !text(q.subject, 100) ||
      !Number.isInteger(q.grade) ||
      q.grade < 1 ||
      q.grade > 20 ||
      !text(q.chapter, 300) ||
      !text(q.lesson, 300) ||
      !text(q.topic, 100) ||
      ![1, 2, 3, 4].includes(q.difficulty) ||
      q.type !== "multiple_choice" ||
      !text(q.question) ||
      !Array.isArray(q.options) ||
      q.options.length !== 4 ||
      !q.options.every((x: unknown) => text(x, 3000)) ||
      new Set(q.options.map((x: string) => x.trim().toLowerCase())).size !==
        4 ||
      !Number.isInteger(q.correctAnswer) ||
      q.correctAnswer < 0 ||
      q.correctAnswer > 3 ||
      !text(q.explanation) ||
      !q.source ||
      !text(q.source.documentId, 200) ||
      !text(q.source.locator, 500)
    )
      throw new Error(
        `Câu ${i + 1} (${q?.id || "thiếu ID"}): cấu trúc hoặc nội dung không hợp lệ.`,
      );
    if (q.clinicalCase !== undefined && !text(q.clinicalCase))
      throw new Error(`Câu ${q.id}: bệnh cảnh không hợp lệ.`);
    if (q.image) {
      const im = q.image;
      if (
        !text(q.clinicalCase) ||
        !text(im.src, 1000) ||
        !/^images\/[\w.-]+\.(png|jpg|jpeg|webp)$/i.test(im.src) ||
        !text(im.alt, 1000) ||
        !text(im.caption, 1000) ||
        !safeUrl(im.sourceUrl) ||
        !text(im.credit, 1000) ||
        !text(im.license, 1000)
      )
        throw new Error(
          `Câu ${q.id}: câu ảnh cần bệnh cảnh, ảnh cục bộ hợp lệ, nguồn và giấy phép.`,
        );
    }
    if (
      q.updates !== undefined &&
      (!Array.isArray(q.updates) ||
        q.updates.some(
          (u: {
            title?: unknown;
            url?: unknown;
            year?: unknown;
            note?: unknown;
          }) =>
            !text(u.title, 1000) ||
            !safeUrl(u.url) ||
            !Number.isInteger(u.year) ||
            !text(u.note, 4000),
        ))
    )
      throw new Error(`Câu ${q.id}: nguồn cập nhật guideline không hợp lệ.`);
    if (ids.has(q.id)) throw new Error(`ID bị trùng: ${q.id}.`);
    if (Object.prototype.hasOwnProperty.call(Object.prototype, q.id))
      throw new Error(`Câu ${q.id}: ID này được dành riêng. Hãy dùng ID khác.`);
    ids.add(q.id);
    const key = (q.clinicalCase || "") + " " + q.question;
    const normalized = key.toLowerCase().replace(/\s+/g, " ").trim();
    if (content.has(normalized)) warnings.push(`Nội dung trùng: ${q.id}`);
    content.add(normalized);
  }
  return { questions: structuredClone(data), warnings };
}
export function validateAttempts(
  data: unknown,
  allowActive = false,
): Attempt[] {
  if (!Array.isArray(data) || data.length > 5000)
    throw new Error("Lịch sử cần là danh sách bài làm (tối đa 5.000).");
  const ids = new Set();
  for (const a of data) {
    if (
      !a ||
      !text(a.id, 100) ||
      ids.has(a.id) ||
      !text(a.bankVersion, 200) ||
      !text(a.algorithmVersion, 20) ||
      !text(a.seed, 100) ||
      !a.config ||
      (a.config.subject !== undefined && !text(a.config.subject, 100)) ||
      (a.config.grade !== undefined &&
        (!Number.isInteger(a.config.grade) ||
          a.config.grade < 1 ||
          a.config.grade > 20)) ||
      (a.config.chapters !== undefined &&
        (!Array.isArray(a.config.chapters) ||
          !a.config.chapters.every((x: unknown) => text(x, 300)))) ||
      !["exam", "practice"].includes(a.config.mode) ||
      typeof a.config.name !== "string" ||
      a.config.name.length > 200 ||
      !Number.isFinite(a.config.minutes) ||
      a.config.minutes < 1 ||
      a.config.minutes > 1440 ||
      !Number.isInteger(a.config.count) ||
      a.config.count < 1 ||
      a.config.count > 2000 ||
      !Array.isArray(a.config.ratios) ||
      a.config.ratios.length !== 4 ||
      a.config.ratios.some(
        (x: unknown) =>
          typeof x !== "number" || !Number.isFinite(x) || x < 0 || x > 100,
      ) ||
      Math.abs(
        a.config.ratios.reduce((s: number, x: number) => s + x, 0) - 100,
      ) > 1e-7 ||
      !Array.isArray(a.config.topics) ||
      !a.config.topics.every((x: unknown) => typeof x === "string") ||
      !Array.isArray(a.config.lessons) ||
      !a.config.lessons.every((x: unknown) => typeof x === "string") ||
      !["all", "with", "without"].includes(a.config.images) ||
      !Number.isFinite(a.startedAt) ||
      a.startedAt < 0 ||
      !(
        (a.status === "completed" &&
          Number.isFinite(a.completedAt) &&
          a.completedAt >= a.startedAt) ||
        (allowActive && a.status === "active" && a.completedAt === null)
      ) ||
      (a.config.mode === "practice"
        ? a.deadline !== null
        : !Number.isFinite(a.deadline) ||
          a.deadline !== a.startedAt + a.config.minutes * 60000) ||
      !Array.isArray(a.questions) ||
      a.questions.length !== a.config.count ||
      !a.answers ||
      typeof a.answers !== "object" ||
      Array.isArray(a.answers) ||
      !Array.isArray(a.flags) ||
      !Number.isInteger(a.current) ||
      a.current < 0 ||
      a.current >= a.config.count
    )
      throw new Error(
        "Bản sao lưu chứa bài làm không hợp lệ hoặc chưa hoàn tất.",
      );
    validateQuestions(a.questions);
    for (const q of a.questions) {
      if (
        !Array.isArray(q.optionOrder) ||
        q.optionOrder.length !== 4 ||
        !q.optionOrder.every(
          (value: unknown) =>
            Number.isInteger(value) && Number(value) >= 0 && Number(value) <= 3,
        ) ||
        new Set(q.optionOrder).size !== 4
      )
        throw new Error("Thứ tự đáp án trong lịch sử không hợp lệ.");
    }
    const qids = new Set(a.questions.map((q: Question) => q.id));
    for (const [id, value] of Object.entries(a.answers))
      if (
        !qids.has(id) ||
        !Number.isInteger(value) ||
        Number(value) < 0 ||
        Number(value) > 3
      )
        throw new Error("Đáp án trong lịch sử không hợp lệ.");
    if (a.flags.some((id: unknown) => !qids.has(id)))
      throw new Error("Câu đánh dấu trong lịch sử không hợp lệ.");
    ids.add(a.id);
  }
  return structuredClone(data);
}
