import Papa from "papaparse";
import type { Question, Attempt } from "../types";
import { validateQuestions, validateAttempts } from "./validation";
export const FILE_LIMIT = 25 * 1024 * 1024;
export function download(
  filename: string,
  data: string,
  mime = "application/json",
) {
  const url = URL.createObjectURL(new Blob([data], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function exportBank(bank: Question[], csv = false) {
  if (csv) {
    download(
      "ngan-hang-san-khoa.csv",
      "\uFEFF" +
        Papa.unparse(
          bank.map((q) => ({
            id: q.id,
            subject: q.subject,
            grade: q.grade,
            chapter: q.chapter,
            lesson: q.lesson,
            topic: q.topic,
            difficulty: q.difficulty,
            type: q.type,
            question: q.question,
            clinicalCase: q.clinicalCase || "",
            options: JSON.stringify(q.options),
            correctAnswer: q.correctAnswer,
            explanation: q.explanation,
            source: JSON.stringify(q.source),
            updates: JSON.stringify(q.updates || []),
            image: q.image ? JSON.stringify(q.image) : "",
          })),
          { escapeFormulae: true },
        ),
      "text/csv;charset=utf-8",
    );
  } else
    download(
      "ngan-hang-san-khoa.json",
      JSON.stringify({ schemaVersion: 1, questions: bank }, null, 2),
    );
}
export async function parseBank(file: File) {
  if (file.size > FILE_LIMIT) throw new Error("Tệp vượt giới hạn 25 MB.");
  const raw = await file.text();
  let data: unknown;
  if (file.name.toLowerCase().endsWith(".csv")) {
    const result = Papa.parse<Record<string, string>>(
      raw.replace(/^\uFEFF/, ""),
      { header: true, skipEmptyLines: true },
    );
    if (result.errors.length)
      throw new Error("CSV không hợp lệ: " + result.errors[0].message);
    data = result.data.map((q) => ({
      ...q,
      grade: Number(q.grade),
      difficulty: Number(q.difficulty),
      correctAnswer: Number(q.correctAnswer),
      options: JSON.parse(q.options),
      source: JSON.parse(q.source),
      updates: q.updates ? JSON.parse(q.updates) : [],
      ...(q.clinicalCase
        ? { clinicalCase: q.clinicalCase }
        : { clinicalCase: undefined }),
      ...(q.image ? { image: JSON.parse(q.image) } : { image: undefined }),
    }));
  } else {
    const parsed = JSON.parse(raw);
    data = Array.isArray(parsed) ? parsed : parsed.questions;
    if (parsed.schemaVersion !== undefined && parsed.schemaVersion !== 1)
      throw new Error("Phiên bản ngân hàng không được hỗ trợ.");
  }
  return validateQuestions(data);
}
export function exportHistory(attempts: Attempt[], csv = false) {
  if (csv) {
    download(
      "lich-su-san-khoa.csv",
      "\uFEFF" +
        Papa.unparse(
          attempts
            .filter((a) => a.status === "completed")
            .map((a) => ({ id: a.id, attempt: JSON.stringify(a) })),
          { escapeFormulae: true },
        ),
      "text/csv;charset=utf-8",
    );
  } else
    download(
      "lich-su-san-khoa.json",
      JSON.stringify(
        {
          schemaVersion: 1,
          attempts: attempts.filter((a) => a.status === "completed"),
        },
        null,
        2,
      ),
    );
}
export async function parseHistory(file: File) {
  if (file.size > FILE_LIMIT) throw new Error("Tệp vượt giới hạn 25 MB.");
  const raw = await file.text();
  if (file.name.toLowerCase().endsWith(".csv")) {
    const parsed = Papa.parse<Record<string, string>>(
      raw.replace(/^\uFEFF/, ""),
      { header: true, skipEmptyLines: true },
    );
    if (parsed.errors.length) throw new Error("CSV lịch sử không hợp lệ.");
    return validateAttempts(parsed.data.map((r) => JSON.parse(r.attempt)));
  }
  const data = JSON.parse(raw);
  if (data.schemaVersion !== 1)
    throw new Error("Phiên bản lịch sử không được hỗ trợ.");
  return validateAttempts(data.attempts);
}
export async function parseActiveBackup(file: File) {
  if (file.size > FILE_LIMIT) throw new Error("Tệp vượt giới hạn 25 MB.");
  const data = JSON.parse(await file.text());
  if (data.schemaVersion !== 1 || data.activeAttempt?.status !== "active")
    throw new Error("Chọn bản dự phòng của một bài đang làm.");
  return validateAttempts([data.activeAttempt], true)[0];
}
