import fs from "node:fs";
import path from "node:path";
const files = ["bank-a", "bank-b", "bank-c", "imaging"];
const bank = files.flatMap((f) =>
  JSON.parse(fs.readFileSync(`src/data/${f}.json`, "utf8")),
);
const sources = JSON.parse(fs.readFileSync("src/data/sources.json", "utf8"));
const sourceIds = new Set(sources.map((s) => s.id));
const ids = new Set(),
  prompts = new Set(),
  errors = [],
  warnings = [];
for (const q of bank) {
  if (ids.has(q.id)) errors.push("Duplicate ID " + q.id);
  ids.add(q.id);
  if (
    !Array.isArray(q.options) ||
    q.options.length !== 4 ||
    new Set(q.options.map((s) => s.trim())).size !== 4 ||
    !Number.isInteger(q.correctAnswer) ||
    q.correctAnswer < 0 ||
    q.correctAnswer > 3
  )
    errors.push("Invalid options " + q.id);
  if (
    ![1, 2, 3, 4].includes(q.difficulty) ||
    q.type !== "multiple_choice" ||
    !q.question ||
    !q.explanation ||
    !q.chapter ||
    !q.lesson ||
    !q.topic
  )
    errors.push("Invalid metadata " + q.id);
  if (!sourceIds.has(q.source?.documentId))
    errors.push("Unknown source " + q.id);
  if (!q.source?.locator) errors.push("Missing locator " + q.id);
  if (q.difficulty >= 3 && !q.clinicalCase)
    warnings.push(
      "Application question without separate clinical case " + q.id,
    );
  const key = ((q.clinicalCase || "") + " " + q.question)
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
  if (prompts.has(key)) errors.push("Duplicate question " + q.id);
  prompts.add(key);
  if (q.image) {
    if (
      !q.clinicalCase ||
      !q.image.credit ||
      !q.image.license ||
      !q.image.sourceUrl ||
      !q.image.caption
    )
      errors.push("Incomplete image question " + q.id);
    if (
      !/^images\/[\w.-]+\.(jpg|png|jpeg|webp)$/.test(q.image.src) ||
      !fs.existsSync(path.join("public", q.image.src))
    )
      errors.push("Missing/unsafe image " + q.id);
  }
  const privateSource = path.join(
    ".local-sources",
    q.source?.documentId + ".json",
  );
  if (fs.existsSync(privateSource)) {
    const data = JSON.parse(fs.readFileSync(privateSource));
    if (
      !data.units.some((u) =>
        q.source.locator.split(/\s*[-–,;]\s*/).some((loc) => loc === u.locator),
      ) &&
      !q.source.locator.includes("mục")
    )
      warnings.push(
        "Locator not directly matched " + q.id + ": " + q.source.locator,
      );
  }
}
const report = {
  total: bank.length,
  levels: [1, 2, 3, 4].map(
    (d) => bank.filter((q) => q.difficulty === d).length,
  ),
  topics: Object.fromEntries(
    [...new Set(bank.map((q) => q.topic))].map((t) => [
      t,
      bank.filter((q) => q.topic === t).length,
    ]),
  ),
  images: bank.filter((q) => q.image).length,
  sourceDocuments: sources.length,
  referencedDocuments: new Set(bank.map((q) => q.source.documentId)).size,
  unreferenced: sources
    .filter((s) => !bank.some((q) => q.source.documentId === s.id))
    .map((s) => ({ id: s.id, title: s.title })),
  errors,
  warnings,
};
fs.mkdirSync("reports", { recursive: true });
fs.writeFileSync(
  "reports/bank-validation.json",
  JSON.stringify(report, null, 2),
);
console.log(
  JSON.stringify(
    { ...report, unreferenced: report.unreferenced.length },
    null,
    2,
  ),
);
if (errors.length || bank.length < 900) {
  console.error(
    "Bank acceptance requires at least 900 valid unique questions.",
  );
  process.exitCode = 1;
}
