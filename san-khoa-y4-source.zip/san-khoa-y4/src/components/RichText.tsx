import katex from "katex";
import "katex/dist/katex.min.css";
export function RichText({ text }: { text: string }) {
  return (
    <>
      {text
        .split(/(\$\$[\s\S]*?\$\$|\$[^$\n]+\$)/g)
        .map((part, i) =>
          part.startsWith("$") ? (
            <span
              key={i}
              dangerouslySetInnerHTML={{
                __html: katex.renderToString(
                  part.replace(/^\$\$?|\$\$?$/g, ""),
                  {
                    throwOnError: false,
                    trust: false,
                    displayMode: part.startsWith("$$"),
                  },
                ),
              }}
            />
          ) : (
            <span key={i}>{part}</span>
          ),
        )}
    </>
  );
}
