import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests",
  fullyParallel: false,
  workers: 1,
  timeout: 30000,
  use: {
    baseURL: process.env.QUIZ_TEST_URL || "http://127.0.0.1:4173",
    viewport: { width: 1280, height: 900 },
    launchOptions: {
      executablePath:
        process.env.CHROME_BIN ||
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    },
  },
  reporter: [["list"], ["json", { outputFile: "reports/browser-tests.json" }]],
});
